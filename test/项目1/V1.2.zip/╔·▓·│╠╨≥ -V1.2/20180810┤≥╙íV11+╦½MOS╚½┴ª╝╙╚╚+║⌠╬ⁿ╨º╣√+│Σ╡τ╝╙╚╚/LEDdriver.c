
#include "LEDdriver.h"
#include "SysConfig.h"
extern  bit f_on_off;
u8 f_led1_4=0;//LED��˸��־λ
u8 f_motor_on=0;
u8 TempLevelNumber=1;
u8 OneSecondCnt;
extern u8 f_mode;
extern bit f_full_v;
extern u8 f_bat_volt;
extern u8 f_bat_save;
extern u8 Battery_RGB_Flag;
extern u8 f_bat_volt2;
void led_light_ctrl(void) //LED��������
{
	if (f_led1_4==F_HALF_LIGHT) //LED1-4������ʾ
	{
         if (++OneSecondCnt >= LEDALL)
         {
            OneSecondCnt = 0;
         }
         switch(TempLevelNumber)
            {
                case 1:
                        if (OneSecondCnt <= LEDON)LED4 = ON;  //����
                        else LED4 = OFF;
                        break;
                case 2:                                       //ȫ��
                        LED3 = OFF; 
                        LED4 = ON;
                        break;
                case 3:                                       
                        LED4 = OFF;
                        if (OneSecondCnt <= LEDON)LED3 = ON;  //����		
                        else LED3 = OFF;
                        break;
                case 4:                                       //ȫ��
                        LED2 = OFF;
                        LED3 = ON;
                        break;
                case 5:                                       
                        LED3 = OFF;
                        if (OneSecondCnt <= LEDON)LED2 = ON;  //����		
                        else LED2 = OFF;
                        break;
                case 6:                                       //ȫ��
                        LED1 = OFF;
                        LED2 = ON;
                        break;
                case 7:                                       
                        LED2 = OFF;
                        if (OneSecondCnt <= LEDON)LED1 = ON;  //����		
                        else LED1 = OFF;
                        break;
                case 8:                                       //ȫ��
                        LED1 = ON;
                        break;
            }        
	}
	else if(f_led1_4==F_BREATHE_LIGHT)//��������
	{
        LED1234();//������
	}
}



#define A_CYCLE 200
#define PWM_TAB_MAX 80
#define PWM_TAB_MIN 1
u8 code HALF_LIGHT_TAB[PWM_TAB_MAX]=//�������Ǻ���COS()�ó� ��ʽ=40-40*cos(a)  a=0-90��
{
	0,0,0,0,0,0,0,0,1,1,
	1,1,1,2,2,2,2,2,3,3,3,
	4,4,4,5,5,5,6,6,7,7,8,
	8,9,9,10,10,11,11,12,12,
	13,13,14,15,15,16,16,17,
	18,18,19,20,20,21,22,23,
	23,24,25,25,26,27,28,28,
	29,30,31,31,32,33,34,35,
	35,36,37,38,38,39,40
};
u8 code ALL_LIGHT_TAB[PWM_TAB_MAX]=//�������Ǻ���COS()�ó� ��ʽ=200-200*cos(a)  a=0-90��
{
	0,0,0,1,1,1,2,2,3,4,5,6,
	6,8,9,10,11,12,14,15,17,18,
	20,22,24,26,27,29,32,34,36,38,
	41,43,45,48,50,53,56,59,61,64,
	67,70,73,76,79,82,86,89,92,96,
	99,102,106,109,113,116,120,123,
	127,131,134,138,142,146,150,153,
	157,161,165,169,173,176,180,184,
	188,192,196,200
};
void LED1234(void)//ɨ������50us������ĺô������Զ���LED�����ȷ�Χ
{   
    static u8 PwmCnt=0;        //PWM������
    static bit PwmDirection=1; //�������־λ
    static u8 PwmDuty=0;       //ռ�ձȳ�ʼ��Ϊ0,ռ�ձȱȽ�������������֮��ȣ�����������������
    static u8  Lookup_Tab_Pointer=0;     //Lookup table pointer

    if(++PwmCnt>=A_CYCLE)            //1�����ڣ�200*50us=10ms��������һ��ռ�ձ�
    {
         PwmCnt=0;
         if(PwmDirection==0)       //��ȫ������
         {
			  if(--Lookup_Tab_Pointer<=PWM_TAB_MIN)
			  { PwmDirection=1;Lookup_Tab_Pointer= PWM_TAB_MIN;}
              if((TempLevelNumber==1)||(TempLevelNumber==3)||(TempLevelNumber==5)||(TempLevelNumber==7))
              {   
                  PwmDuty=HALF_LIGHT_TAB[Lookup_Tab_Pointer];//��������
              }
              else //ȫ������
              {
                  PwmDuty=ALL_LIGHT_TAB[Lookup_Tab_Pointer];
              }
         }
         else  //����ȫ��
         {
			  if(++Lookup_Tab_Pointer>=PWM_TAB_MAX)
			  {PwmDirection=0;Lookup_Tab_Pointer=PWM_TAB_MAX-1;}
              if((TempLevelNumber==1)||(TempLevelNumber==3)||(TempLevelNumber==5)||(TempLevelNumber==7))
			  {
				  PwmDuty=HALF_LIGHT_TAB[Lookup_Tab_Pointer];
			  }
              else //ȫ������
			  {
                  PwmDuty=ALL_LIGHT_TAB[Lookup_Tab_Pointer];
			  }
         }  
     }
     if(PwmCnt<=PwmDuty)           //�ı����״̬
     {  
         switch(TempLevelNumber)
         {
            case 1:LED_BLUE= ON;  break;
            case 2:LED_BLUE= ON;  break;
            case 3:LED_YELLOW= ON;break;
            case 4:LED_YELLOW= ON;break;
            case 5:LED_ORANGE= ON;break;
            case 6:LED_ORANGE= ON;break;
            case 7:LED_RED= ON;   break;
            case 8:LED_RED= ON;   break;      
         } 
     }
     else
     {
        LED1= OFF;LED2= OFF;LED3= OFF;LED4= OFF;
     }
}

#define A_OTHER_CYCLE 200
void RGB_Driver(void)
{   
    static u8  RGB_PwmCnt=0;       //PWM������
    static bit RGB_PwmDirection=0; //�������־λ
    static u8  RGB_PwmDuty=A_OTHER_CYCLE;     //ռ�ձȳ�ʼ��Ϊ200
    if((f_mode==MODE_CHARGING)&&(f_full_v==0))   //δ������ʱ
     {
        if(++RGB_PwmCnt>=A_OTHER_CYCLE)            //1�����ڵ�������һ��ռ�ձ�
        {
             RGB_PwmCnt=0;
             if(RGB_PwmDirection==0)       //��ȫ������
             {
                  if(--RGB_PwmDuty<=0)     //ռ�ձȼ�1��Ϊ0��ı䷽���־λ
                      RGB_PwmDirection=1;                
             }
             else                      //����ȫ��
             {
                  if(++RGB_PwmDuty>=A_OTHER_CYCLE)   //ռ�ձȼ�1����100��ñ䷽���־λ
                      RGB_PwmDirection=0;
             }  
         }
         if(RGB_PwmCnt<=RGB_PwmDuty)           //�ı����״̬
         {
                      //  f_bat_volt=BAT_volt();
           // if(Battery_RGB_Flag==0) Battery_RGB_Flag=f_bat_volt;
           // if(f_bat_volt>Battery_RGB_Flag) f_bat_volt=Battery_RGB_Flag;//ȡ��Сֵ
           // else if(f_bat_volt<=Battery_RGB_Flag) Battery_RGB_Flag=f_bat_volt;//��ֹ��ѹ������ָʾ�ƴ���
           // if(f_bat_save<=BAT_LOW) f_bat_volt=BAT_LOW;//������ʱ���ﵽ�͵�ˮƽ������ʱ��δ��������������ʾ�Ƶ�
            switch (f_bat_volt) 
            {
               case BAT_GREEN:          {IOCTRL(LEDR,OFF);IOCTRL(LEDB,OFF);  IOCTRL(LEDG,ON);} break;
               case BAT_YELLOW:           {IOCTRL(LEDR,ON); IOCTRL(LEDB,OFF);  IOCTRL(LEDG,ON);} break;
               default:                 {IOCTRL(LEDR,ON); IOCTRL(LEDB,OFF);  IOCTRL(LEDG,OFF);} break;
            } 
//            switch(f_bat_volt)
//             {
//                case BAT_GREEN: IOCTRL(LEDG,ON); break;               
//                case BAT_YELLOW: IOCTRL(LEDR,ON);IOCTRL(LEDG,ON); break;
//                case BAT_LOW: IOCTRL(LEDR,ON);IOCTRL(LEDG,ON); break;
//                default:IOCTRL(LEDR,ON); break; 
//                 
//             }
         }
             
         else
            {IOCTRL(LEDR,OFF); IOCTRL(LEDB,OFF); IOCTRL(LEDG,OFF);}
     }
}




#define motor_one_start_tick    1
#define motor_one_stop_tick     120
#define motor_two_start_tick    240
#define motor_two_stop_tick     360
#define motor_three_start_tick  480
#define motor_three_stop_tick   600
#define motor_end_tick          720

////////////////////////////////////////////////////////////
//�����
////////////////////////////////////////////////////////////
void Motor_program(void)			//2ms �����2��
{	
      static u16 motor_pwm;
      if(f_motor_on==1)		//�����
      {		  
			if(++motor_pwm ==motor_one_start_tick)
				motor_on ;
			else if(motor_pwm ==motor_one_stop_tick)
				motor_off;
			if(motor_pwm >=motor_two_start_tick)//2ms*2500=5s
			{
				motor_pwm =0;
				motor_off;
				f_motor_on=0;
			}
	  }
      else if(f_motor_on==2)		//�����
      {		  
			if(++motor_pwm ==motor_one_start_tick)
				motor_on ;
			else if(motor_pwm ==motor_one_stop_tick)
				motor_off;
			if(motor_pwm ==motor_two_start_tick)
				motor_on;
			else if(motor_pwm ==motor_two_stop_tick)
				motor_off;
			if(motor_pwm >=motor_three_start_tick)//2ms*2500=5s
			{
				motor_pwm =0;
				motor_off;
				f_motor_on=0;
			}
	  }
      else if(f_motor_on==3)		//�����
      {		  
			if(++motor_pwm ==motor_one_start_tick)
				motor_on ;
			else if(motor_pwm ==motor_one_stop_tick)
				motor_off;
			if(motor_pwm ==motor_two_start_tick)
				motor_on;
			else if(motor_pwm ==motor_two_stop_tick)
				motor_off;
			if(motor_pwm ==motor_three_start_tick)
				motor_on;
			else if(motor_pwm ==motor_three_stop_tick)
				motor_off;			
            if(motor_pwm >=motor_end_tick)//2ms*2500=5s
			{
				motor_pwm =0;
				motor_off;
				f_motor_on=0;
			}
	  }      
	  else
		 motor_off;
		
}
