/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright(c) 2011 Nuvoton Technology Corp. All rights reserved.                                         */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

//***********************************************************************************************************
//  Nuvoton Technoledge Corp. 
//  Author: PU20 Department. 
//  Tel: 03-5770066#8043
//  E-Mail: MicroC-8bit@nuvoton.com
//***********************************************************************************************************
//  Application: WDT Function 
//  Set watch counter and enable WDT interrupt. WDT ISR will be execute when WDT time out. 
//  
//  Output : P1.4 & P2.1 toggle by WDT interrupt   
//***********************************************************************************************************

//========================================= How to set WDT register =========================================
//
//  1.WDT time-out period is 64 /(Fwck + Prescalar);
//     
//  2.Fwck is frequency of WDT clock source             
//
//  3.Presalar = WDCON0 & 0x07
//===========================================================================================================

//------------------------- <<< Use Configuration Wizard in Context Menu >>> --------------------------------
//
//<o0.0..2> WDT Perscalar Select
//      <0=> 1/1    <1=> 1/2    <2=> 1/8    <3=> 1/16     
//      <4=> 1/32   <5=> 1/64   <6=> 1/128  <7=> 1/256
// <h> UART pin Select
//     <o1.6> Uart pin
//         <0=> Select P1.0, P1.1 as UART pin            <1=> Select P2.6, P2.7 as UART pin(28 pin only) 
// </h>
//-------------------------------- <<< end of configuration section >>> -------------------------------------

//#define WDT_CLK_DIV     0x01
#define WDT_CLK_DIV     0x07
#define Uart_Port_Sel   0x00

#include <stdio.h>
#include "N79E81x.h"
#include "Typedef.h"
#include "Define.h"
#include "main.h" 
#include "WDT.h"
#include "SysConfig.h"

//-----------------------------------------------------------------------------------------------------------
void WTD_init(void)
{
 
    TA = 0xAA;    
    TA = 0x55;  
	WDCON0 &= 0x40; //0100 1000
    TA = 0xAA;    
    TA = 0x55; 	 
    WDCON0 |= WDT_CLK_DIV;              // Select bit length of WDT counter
    clr_WDTF;
    EWDI = 1;                           // Enable WDT interrupt
    set_WDCLR;                          // Clear WDT counter
    set_WDTEN;                          // Enable WDT
    set_ewrst;//jason
    EA=1;                      // Enable interrupt
}
//-----------------------------------------------------------------------------------------------------------
void WDT_ISR(void)  interrupt 10        // Vecotr @  0x53
{   
    clr_WDTF;                           // Clear WDT flag
    set_WDCLR;
   
    soft_reset();	
			
    
}
//-----------------------------------------------------------------------------------------------------------