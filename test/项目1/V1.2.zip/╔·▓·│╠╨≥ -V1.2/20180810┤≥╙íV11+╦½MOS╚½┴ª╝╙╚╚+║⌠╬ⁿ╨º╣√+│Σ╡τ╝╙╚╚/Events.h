#ifndef _EVENTS_H_
#define _EVENTS_H_

//initialize Adc
void Init_Adc(unsigned char ADCChannel);

//prosess of ADC
unsigned int Adc_Sampling(unsigned char ADCChannel);

void Int_Int0_Data(void);

//events of power down
void PowerDown(void);

#endif