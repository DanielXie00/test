#include "SysConfig.h"
#include "intrins.h"
#include "Typedef.h"
#include "Scom.h"
extern bit f_tempctrl;
extern bit f_on_off;
extern bit f_full_v;
extern bit f_outsid_v;
//extern bit f_hot_mode_ctrl;
//extern bit f_wax_mode_ctrl;
extern u8 Key_Value;
extern u8 f_motor_on;//�����
extern u8 TempLevelNumber;
extern UINT16 TempPwm;
extern u16 time_pwm_wax;
extern u16 Bat_ad_average;
extern u8 f_mode;
void KBI_init()
{
    KBLS1 = 0x82; //�����½��ض���Ӧ            
    KBLS0 = 0x00;//P07�����أ�P01,�½���
	KBIF = 0x00;                        // Clear KBF
    EKB = 1;                            // Enable KBI Interrupt
    KBIE = 0x82;                  // KBI Enable   P01/P07�ж�ʹ��                            
    EA  = 1;                            // Enable EA

}
void Halt_OffDevice(void) //�ػ�����
{	
    my_Sprintf("Halt_OffDevice",88);
//    P_WAX=PIN_OFF;P_TEM=PIN_OFF;
	Dis_AdcSampling();//�ر�AD
    TR0=0;//�رն�ʱ������ֹ����˸
//    TR1 = 0;//�رմ���
    Set_Period_Pwm(0);

    VCC1_OFF;//���ߣ���ֹ   
//    LEDR=0;
    P_TEM=PIN_OFF;
    P_WAX=PIN_OFF; 
//    LEDG=0;
//    LEDB=0;
    P31=0;
    P30=0;
	IOCTRL(LED1,OFF); 
	IOCTRL(LED2,OFF); 
	IOCTRL(LED3,OFF); 
	IOCTRL(LED4,OFF); 
	IOCTRL(LEDR,OFF); 
	IOCTRL(LEDG,OFF); 
	IOCTRL(LEDB,OFF); 
    VCC1_OFF;//���ߣ���ֹ
    
    MOTOR=0;
    IO_KEY_MODE_CHECK=0; 
    IO_KEY_POWER=1;    
    P02=1;
    IO_T_Chek=0;
    P04=1;
    P05=0;
    P06=0;
    P07=0;
    P10=0;
    P11=0;
    P25=0;
    P24=0;
    P00 = 0;
    IO_KEY_CHARGED=0;
    P_WAX=PIN_OFF;P_TEM=PIN_OFF;TempPwm=0;
    time_pwm_wax=0;
    KBI_init();//KBI�жϳ�ʼ��
	P_WAX=PIN_OFF;    
    P00 = 0;
    set_WDCLR; //������Ź�

    Key_Value=0;//
    f_mode=MODE_SHUTDOWN;//
    f_on_off=SHUTDOWN;
    f_outsid_v=0;
   // while(IO_KEY_POWER)//�����̧�𰴼��Ͳ�����
    {
        set_WDCLR;
        EA=1;
        PCON |= 0x02;  //break;

    }

}
void soft_reset(void) //��λ����
{
   // my_Sprintf("soft_reset",88);
	P_WAX=PIN_OFF;P_TEM=PIN_OFF;TempPwm=0;
    EA=0;
	TA = 0xAA;
    TA = 0x55;
    CHPCON &= 0xfd;
	TA = 0xAA;
    TA = 0x55;
	CHPCON |= 0x80;
    EA=1;
    P_WAX=PIN_OFF;P_TEM=PIN_OFF;
    while(1){}
        
}



void DelayMS(unsigned int ch)
{
	set_WDCLR;
	while(--ch);  
	set_WDCLR;
		
}

 
