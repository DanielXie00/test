 /*
 * Gas_Gauge driver for CW2015/2013
 * Copyright (C) 2012, CellWise
 *
 * Authors: ChenGang <ben.chen@cellwise-semi.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as
 * published by the Free Software Foundation.And this driver depends on 
 * I2C and uses IIC bus for communication with the host.
 *
 */

#include "N79E81x.h" 
#include <cw2015_battery.h>
#include "intrins.h"
#include "typedef.h"
#include "ACC.h"
#include "Scom.h"
#include "WDT.h"


#define	DELAY_100US		100
#define I2C_DELAY		20

#define	DELAY_100mS		255


#define REG_VERSION             0x0
#define REG_VCELL               0x2
#define REG_SOC                 0x4
#define REG_RRT_ALERT           0x6
#define REG_CONFIG              0x8
#define REG_MODE                0xA
#define REG_BATINFO             0x10

#define MODE_SLEEP_MASK         (0x3<<6)
#define MODE_SLEEP              (0x3<<6)
#define MODE_NORMAL             (0x0<<6)
#define MODE_QUICK_START        (0x3<<4)
#define MODE_RESTART            (0xf<<0)

#define CONFIG_UPDATE_FLG       (0x1<<1)
#define ATHD                    (0xA<<3)        //ATHD = 10%

#define	READ_CW2015				0xc5
#define	WRITE_CW2015			0xc4

#define SIZE_BATINFO        64

//#define CW_I2C_SPEED            100000          // default i2c speed set 100khz
#define BATTERY_UP_MAX_CHANGE   720             // the max time allow battery change quantity
#define BATTERY_DOWN_CHANGE   90                // the max time allow battery change quantity
#define BATTERY_DOWN_MIN_CHANGE 60             // the min time allow battery change quantity when run
#define BATTERY_DOWN_MIN_CHANGE_SLEEP 1800      // the min time allow battery change quantity when run 30min

#define SYSTEM_SHUTDOWN_VOLTAGE  0x23dc//2.8V        //set system shutdown voltage related in battery info.
//#define BAT_LOW_INTERRUPT    1

bit e_no_load_flag1 = 0; //û�и��ص�����־λ	
//bit CHARGE = 1; //�Ƿ�ӳ������־λ��1Ϊ�ӳ������0Ϊ�γ������
bit CHARGE = 0; //�Ƿ�ӳ������־λ��1Ϊ�ӳ������0Ϊ�γ������//JASON
bit jump_flag =0;
unsigned char xdata e_status =4; //ϵͳ״̬��־��0:���������;1:����;2:�ر�A·���;3:�ر�B·���;4:�ر��������
unsigned int allow_change =0;
unsigned int allow_change3 =0;
unsigned char allow_change2 =0;
unsigned char if_quickstart =0;
unsigned char xdata reset_loop =0;
unsigned int  xdata ad_voltage;

STRUCT_CW_BATTERY   cw_bat;

extern BIT StartAddPower;
extern bit cw_read(unsigned char PointReg,unsigned char *pData,unsigned char Data_Length);
extern bit cw_write(unsigned char PointReg,unsigned char *pData,unsigned char Data_Length);
extern void delay_us(unsigned char us);



////////////////////////////////////////////////////////////////////////////////////
////global function: 'cw_bat_work()'  and  'cw_bat_init()'                      ////
////'cw_bat_work()'need be called by main.c in every second                     ////
////'cw_bat_init()'need be called by main.c in system-init after power on reset ////
////////////////////////////////////////////////////////////////////////////////////

//void delay_us(unsigned char us)
//{
//	/*
//	make a us*1/1000 second delay
//	*/
//}

////void delay_us(unsigned char us)
//void delay_us(unsigned int us)
//{
//	unsigned char i;
//	for(i = 0; i < us; i++)
//	{
//		//_clrwdt();
//		_nop_();
//		/*for(j = 0; j < 5; j++)
//		{
//			_nop();
//		}*/
//	}
//}
//	
//bit cw_read(unsigned char PointReg,unsigned char *pData,unsigned char Data_Length)
//{
// 	set_WDCLR;
//	Data_Length = Data_Length;
//
//
///* make a IIC read function 
//   refer from datasheet: 
// -----------------------StartIIC-----------------------
// ...
// -----------------------IC_Write_Address---------------
// ...
// -----------------------PointReg(first Register address)
// ...
// -----------------------Re-startIIC--------------------
// ...
// -----------------------IC_Read_Address----------------
// ...
// -----------------------Read_Data(first data)----------
// ...
// -----------------------Re-read to Data_Length---------
// ...
// -----------------------StopIIC------------------------
// 
//   if communication sccessfully
//   return 0
//   if communication failed(retry 6 times)
//   return -1
//*/
//	set_WDCLR;
//	*pData = Single_ReadI2C(FUEL_ADDR,PointReg);
////	if (*pData != 0XFF)
////	{		 
////		return 0;
////	}
////	 else
////	 {
////		return 1;	 
////	 }
//
//	return 0;
//}
//
//bit cw_write(unsigned char PointReg,unsigned char *pData,unsigned char Data_Length)
//{
//	unsigned char tmp;
// 
//	Data_Length = Data_Length;
//
//	Single_WriteI2C(FUEL_ADDR,PointReg,*pData);
//
//	tmp = Single_ReadI2C(FUEL_ADDR,PointReg);
//	if (tmp == *pData)
//	{
//	   return 0;	
//	}
//	else
//	{
//	   return 1;
//	}
//
//
//
///* make a IIC read function 
//   refer from datasheet:
// -----------------------StartIIC-----------------------
// ...
// -----------------------IC_Write_Address---------------
// ...
// -----------------------PointReg(first Register address) 
// ...
// -----------------------Write_Data(first data)---------
// ...
// -----------------------Re-write to Data_Length--------
// ...
// -----------------------StopIIC------------------------ 
//   
//   if communication sccessfully
//   return 0
//   if communication failed(retry 6 times)
//   return -1
//*/
//
//
//}

bit cw_update_config_info(void)
{
	bit ret = 0;
	unsigned char i;
	unsigned char reset_val;
	unsigned char reg_val;
	/* make sure no in sleep mode */
	ret = cw_read(REG_MODE, &reg_val, 1);
	if(ret)
	{
		return 1;
	}
	if((reg_val & MODE_SLEEP_MASK) == MODE_SLEEP)
	{
		return 1;
	}
	/* update new battery info */
	for(i = 0; i < SIZE_BATINFO; i++)
	{
		reg_val =cw_bat_config_info[i];
		ret = cw_write(REG_BATINFO+i, &reg_val, 1);
	}
    if(ret)
    {
    	return 1;
    }
	/* readback & check */
	for(i = 0; i < SIZE_BATINFO; i++)
	{
		ret = cw_read(REG_BATINFO+i, &reg_val, 1);
		if(ret)
		{
			return 1;
		}
		if(reg_val != cw_bat_config_info[i])
		{
			return 1;
		}
	}
	/* set cw2015/cw2013 to use new battery info */
	ret = cw_read(REG_CONFIG, &reg_val, 1);
	if(ret)
	{
		return 1;
	}
	reg_val |= CONFIG_UPDATE_FLG;   /* set UPDATE_FLAG */
	reg_val &= 0x07;                /* clear ATHD */
	reg_val |= ATHD;                /* set ATHD */
	ret = cw_write(REG_CONFIG, &reg_val, 1);
	if(ret)
	{
		return 1;
	}
	/* reset */
	reset_val = MODE_NORMAL;
	reg_val = MODE_RESTART;
	ret = cw_write(REG_MODE, &reg_val, 1);
	if(ret)
	{
		return 1;
	}
	delay_us(DELAY_100US);  //delay 100us      
	ret = cw_write(REG_MODE, &reset_val, 1);
	if(ret)
	{
		return 1;
	}   
	return 0;
}

bit cw_init(void)
{
	bit ret;
	unsigned char i;
	unsigned char idx;

	unsigned char reg_val = MODE_NORMAL;
//	unsigned char tempmode;

#if 0
	ret = cw_read(REG_MODE, &reg_val, 1);
	if (ret < 0)
		return ret;
#endif

//	Send_Data_To_iPhone(0Xe1);
//	cw_read(REG_MODE, &tempmode, 1);//JASON 	
//	Send_Data_To_iPhone(tempmode);



	/* wake up cw2015/13 from sleep mode */

		ret = cw_write(REG_MODE, &reg_val, 1);



//		Send_Data_To_iPhone(0Xe2);
//		cw_read(REG_MODE, &tempmode, 1);//JASON 		
//		Send_Data_To_iPhone(tempmode);


		if(ret)
		{
			return 1;
		}

	/* check ATHD if not right */
	ret = cw_read(REG_CONFIG, &reg_val, 1);

	//JASON 
//	Send_Data_To_iPhone(0Xa1);
//	Send_Data_To_iPhone(reg_val);

	if(ret)
	{
//		Send_Data_To_iPhone(0Xa0);
		return 1;
	}
	if((reg_val & 0xf8) != ATHD)
	{
		//"the new ATHD need set"
		reg_val &= 0x07;    /* clear ATHD */
		reg_val |= ATHD;    /* set ATHD */
		ret = cw_write(REG_CONFIG, &reg_val, 1);



//		Send_Data_To_iPhone(0Xa2);
//		cw_read(REG_CONFIG, &tempmode, 1);//JASON 
//		Send_Data_To_iPhone(tempmode);




		if(ret)
		{
			return 1;
		}
	}
	
	/* check config_update_flag if not right */
	ret = cw_read(REG_CONFIG, &reg_val, 1);
	if(ret)
	{ 
		return 1;
	}
	if(!(reg_val & CONFIG_UPDATE_FLG))
	{
		//"update flag for new battery info need set"
		ret = cw_update_config_info();
		if(ret)
		{
			return 1;
		}
	}
	else
	{
		for(i = 0; i < SIZE_BATINFO; i++)
		{ 
			ret = cw_read(REG_BATINFO +i, &reg_val, 1);
			if(ret)
			{
				return 1;
			}
			if(cw_bat_config_info[i] != reg_val)
			{
				break;
			}
		}
		if(i != SIZE_BATINFO)
		{
			//"update flag for new battery info need set"
			ret = cw_update_config_info();
			if(ret)
			{
				return 1;
			}
		}
	}
	/* check SOC if not eqaul 255 */
	 for (i = 0; i < 30; i++) {
                ret = cw_read(REG_SOC, &reg_val, 1);
                if (ret)
                        return 1;
                else if (reg_val <= 0x64) 
                        break;
                
				//for (idx = 0; idx < 255; idx++)
				for (idx = 0; idx < 80; idx++)
				{
	                delay_us(DELAY_100mS);//delay 100ms	
				}

        }
        if (i >=30){
        	   reg_val = MODE_SLEEP;
             ret = cw_write(REG_MODE, &reg_val, 1);

//			 Send_Data_To_iPhone(0X90);
//			 Send_Data_To_iPhone(0X90);
             // "cw2015/cw2013 input unvalid power error_2\n";
             return 1;
        } 
	
	return 0;
}

bit cw_quickstart(void)
{
	bit ret = 0;
	unsigned char reg_val = MODE_QUICK_START;
	ret = cw_write(REG_MODE, &reg_val, 1);     //(MODE_QUICK_START | MODE_NORMAL));  // 0x30
	if(ret)
	{
		//"Error quick start1"
		return 1;
	}   
	reg_val = MODE_NORMAL;
	ret = cw_write(REG_MODE, &reg_val, 1);
	if(ret)
	{
		//"Error quick start2"
		return 1;
	}
	return 1;
}

unsigned char cw_get_capacity(void)
{
	bit ret = 0;
	unsigned char allow_capacity;
	unsigned char reg_val;
	unsigned char reset_val;
	unsigned char cw_capacity;
	//int charge_time;

	ret = cw_read(REG_SOC, &reg_val, 1);
	if(ret)
	{
		return ret;
	}
	//ret = cw_read(REG_SOC + 1, &reg_val, 1);
        
	cw_capacity = reg_val;
	
	if ((cw_capacity < 0) || (cw_capacity > 100)) {
                // "get cw_capacity error; cw_capacity = %d\n"
                reset_loop++;
                
            if (reset_loop >5){ 
            	
                reset_val = MODE_SLEEP;             
                ret = cw_write(REG_MODE, &reset_val, 1);
                if (ret)
                    return ret;
                reset_val = MODE_NORMAL;
                delay_us(DELAY_100US);
                ret = cw_write(REG_MODE, &reset_val, 1);
                if (ret)
                    return ret;
                                              
                //ret = cw_init(cw_bat);//JASON	
				ret = cw_init();

                   if (ret) 
                     return ret;
                reset_loop =0;               
            }
                                     
            return cw_bat.capacity;
        }else {
        	reset_loop =0;
        }
	
	if(((cw_bat.usb_online == 1) && (cw_capacity <= (cw_bat.capacity - 1)) && (cw_capacity > (cw_bat.capacity - 9)))
			|| ((cw_bat.usb_online == 0) && (cw_capacity == (cw_bat.capacity + 1))))
	{
		// modify battery level swing
		if(!((cw_capacity == 0 && cw_bat.capacity <= 2)||(cw_capacity == 100 && cw_bat.capacity == 99)))
		{			
			cw_capacity = cw_bat.capacity;
		}
	}
		
	if((cw_bat.usb_online == 1) && (cw_capacity >= 95) && (cw_capacity <= cw_bat.capacity) )
	{     
		// avoid not charge full
		allow_change++;
		if(allow_change >= BATTERY_UP_MAX_CHANGE)
		{
			allow_capacity = cw_bat.capacity + 1; 
			cw_capacity = (allow_capacity <= 100) ? allow_capacity : 100;
			jump_flag =1;
			allow_change =0;
		}
		else if(cw_capacity <= cw_bat.capacity)
		{
			cw_capacity = cw_bat.capacity; 
		}
	}
  else if(((cw_bat.usb_online == 0) || (cw_bat.usb_online == 2)) && (cw_capacity <= cw_bat.capacity ) && (cw_capacity >= 90) && (jump_flag == 1))
	{
		// avoid battery level jump to CW_BAT
		//if(cw_bat.usb_online == 0) 
		   allow_change++;
		if(allow_change >= BATTERY_DOWN_MIN_CHANGE)
		{
			allow_capacity = cw_bat.capacity - 1;
			allow_change =0; 
			if (cw_capacity >= allow_capacity)
			{
				jump_flag =0;
			}
			else
			{
				cw_capacity = (allow_capacity > 0) ? allow_capacity : 0;
			}
		}
		else if(cw_capacity <= cw_bat.capacity)
		{
			cw_capacity = cw_bat.capacity;
		}
	}
	else
  {
  		allow_change =0;
  }
	
  if((cw_capacity == 0) && (cw_bat.capacity > 1))
	{
		// avoid battery level jump to 0% at a moment from more than 2%
		allow_change2 ++;
		if(allow_change >= BATTERY_DOWN_CHANGE)
		{
			allow_capacity = cw_bat.capacity - 1;
			cw_capacity = (allow_capacity >= cw_capacity) ? allow_capacity : cw_capacity;
			allow_change2 =0;
		}
		reg_val = MODE_NORMAL;
		ret = cw_write(REG_MODE, &reg_val, 1);
		if(ret)
		{
			return 1;
		}
	}

	if((cw_bat.usb_online == 1) &&(cw_capacity == 0))
	{		  
		allow_change3++;
		if((allow_change3 >= BATTERY_DOWN_MIN_CHANGE_SLEEP) && (if_quickstart == 0))
		{
			cw_quickstart();      // if the cw_capacity = 0 the cw2015 will qstrt
			if_quickstart = 1;
			allow_change3 =0;
		}
	}
	else if((if_quickstart == 1)&& ((cw_bat.usb_online == 0) || (cw_bat.usb_online == 2)))
	{
		if_quickstart = 0;
	}

/*
	if(cw_bat.chg_ok_pin != INVALID_GPIO)
	{
		if((cw_capacity == 100) && (gpio_get_value(cw_bat.chg_ok_pin) != cw_bat.chg_ok_level))
		{
			cw_capacity = 99;
		}
	}
*/

#ifdef SYSTEM_SHUTDOWN_VOLTAGE
  
//  ad_voltage =cw_get_vol();

	if(((cw_bat.usb_online == 0) || (cw_bat.usb_online == 2)) && (cw_capacity <= 10) && (ad_voltage <= SYSTEM_SHUTDOWN_VOLTAGE))
	{
/*		
		allow_change ++;
		if(allow_change >= BATTERY_DOWN_MIN_CHANGE)
		  {
			   allow_capacity = cw_bat.capacity - 2;
			   allow_change =0; 
			   cw_bat.capacity = (cw_bat.capacity <= 100) ? allow_capacity : 100;
*/
		if(if_quickstart > 10)
		{      	      	
			cw_quickstart();
			if_quickstart = 12;
			cw_capacity = 0;
		}
		else if(if_quickstart <= 10)
		{
			if_quickstart =if_quickstart+2;
			//"the cw201x capacity is 0 !!!!!!!, funciton: %s, line: %d\n", __func__, __LINE__);
		}
	}
	else if((cw_bat.usb_online == 1)&& (if_quickstart <= 12))
	{
		if_quickstart = 0;
	}
#endif
	return(cw_capacity);
}

unsigned int cw_get_vol(void)
{
	//bit ret = 0;//JASON
	unsigned char ret = 0;
	unsigned char get_ad_times;
	//unsigned int reg_val[2] = {0 , 0};
	unsigned char reg_val[2] = {0 , 0};//JASON

	unsigned int ad_value = 0;
	unsigned int ad_buff = 0;
	unsigned int ad_value_min = 0;
	unsigned int ad_value_max = 0;

	for(get_ad_times = 0; get_ad_times < 3; get_ad_times++)
	{
		ret = cw_read(REG_VCELL, &reg_val[0], 2);
		if(ret)
		{
			return 1;
		}
		ad_buff = (reg_val[0] << 8) + reg_val[1];
	
		if(get_ad_times == 0)
		{
			ad_value_min = ad_buff;
			ad_value_max = ad_buff;
		}
		if(ad_buff < ad_value_min)
		{
			ad_value_min = ad_buff;
		}
		if(ad_buff > ad_value_max)
		{
			ad_value_max = ad_buff;
		}
		ad_value += ad_buff;
	}
	ad_value -= ad_value_min;
	ad_value -= ad_value_max;
//	ad_value >> 3;
	return(ad_value);       //14λADCת��ֵ
}

#ifdef BAT_LOW_INTERRUPT
unsigned char cw_get_alt(void)
{
        signed char ret = 0;
        unsigned int reg_val;
        unsigned char alrt;
        
        ret = cw_read(REG_RRT_ALERT, &reg_val, 1);
        if (ret)
                return 0;
        alrt = reg_val >>7;
        
        //dev_info(&cw_bat->client->dev, "read RRT %d%%. value16 0x%x\n", alrt, value16);
        reg_val = reg_val&0x7f;
        ret = cw_write(REG_RRT_ALERT, &reg_val, 1);
        if(ret) {
                //dev_err(&cw_bat->client->dev, "Error clear ALRT\n");
                return 0;
        }
        
        return (signed char)alrt;
}

static void ALRT_ISR()interrupt 
{
   
    cw_get_alt();
       
}
#endif
#if 0
unsigned int cw_get_time_to_empty(void)
{
        signed char ret;
        unsigned char reg_val;
        unsigned int value16;

        ret = cw_read(REG_RRT_ALERT, &reg_val, 1);
        if (ret)
                return 1;

        value16 = (unsigned int)reg_val;

        ret = cw_read(REG_RRT_ALERT + 1, &reg_val, 1);
        if (ret)
                return 1;

        value16 = ((value16 << 8) + reg_val) & 0x1fff;
       
        return value16;
}
#endif
void update_capacity(void)
{
	unsigned char cw_capacity;
	cw_capacity = cw_get_capacity();
	if((cw_capacity <= 100) && (cw_bat.capacity != cw_capacity))
	{       
		cw_bat.capacity = cw_capacity;
	}
}

/*
void update_vol(void)
{
	unsigned int cw_voltage;
	cw_voltage = cw_get_vol();
	if(cw_bat.voltage != cw_voltage)
	{
		cw_bat.voltage = cw_voltage;
	}
}


static void update_time_to_empty(void)
{
	signed int rrt;
	rrt = cw_get_time_to_empty();
	if((rrt >= 0) && (cw_bat.time_to_empty != rrt))
	{
		cw_bat.time_to_empty = (unsigned int)rrt;
	}       
}*/

/*static void update_alt(void)
{
	signed int alt;
	alt = cw_get_alt();
	if ((rrt >= 0) && (cw_bat.alt != alt))
	{
		cw_bat.alt = (unsigned int)alt;
	}       
}*/

void update_usb_online(void)
{
	/*detect usb_charger plug-in*/
	//if((/*usb_det_pin == LOW*/) &&(cw_bat->dc_online != 0))
	
//	if( CHARGE == 0 && e_no_load_flag1 == 0 )   //���ϳ����ͬʱû�нӸ���

	if (StartAddPower)
	{
		e_no_load_flag1 = 1;
	}
	else
	{
		e_no_load_flag1 = 0; 	
	}

	if( CHARGE == 1 && e_no_load_flag1 == 0 )   //���ϳ����ͬʱû�нӸ���/JASON
	{
		cw_bat.usb_online = 1;  ///charging
	}
//	if( CHARGE == 1 )  //�γ������

	if( CHARGE == 0)  //�γ������//JASON
	{
//		if( e_status != 4 )   //������йر�״̬
//		{
//			cw_bat.usb_online = 0;  ///discharging
//		}
//		else
//		{
			cw_bat.usb_online = 0;	//
//		}
	}
	if( CHARGE == 1 && e_no_load_flag1 == 1 )   //�߳�߷�
	{
		cw_bat.usb_online = 2;
	}
}

////////////////////////////////////////MCUһ�����һ��//////////////////////////////////////////
void cw_bat_work(void)
{

	ad_voltage =cw_get_vol();
	update_usb_online();
	update_capacity();	




//	Send_Data_To_iPhone(0XEE);
//	//Send_Data_To_iPhone(ad_voltage>>8);
//	//Send_Data_To_iPhone(ad_voltage & 0XFF); 
//	//Send_Data_To_iPhone(cw_bat.capacity>>8);
//	Send_Data_To_iPhone(cw_bat.capacity & 0XFF);


	//update_vol();
	//update_time_to_empty();
	//update_alt();

}
/*
static void cw_bat_gpio_init(void)
{
     
     usb_det_pin -- init
     alt_pin  -- init
 
     return 0;
}
*/

///////////////////////////////////////MCU������ʼ��ʱ����.//////////////////////////////////////
void cw_bat_init(void)
{
	bit ret;
	unsigned char loop = 0;
	//cw_bat_gpio_init();
	ret = cw_init();
	while((loop++ < 200) && (ret != 0))
	//while((loop++ < 3) && (ret != 0))//JASON
	{
		ret = cw_init();
	}
	
	cw_bat.usb_online = 2;
	cw_bat.capacity = 1;
	//cw_bat.voltage = 0;
	//cw_bat->status = 0;
	//cw_bat.time_to_empty = 0;
	//cw_bat->alt = 0;
}

//void InitFuel(void)
//{
//	UINT8 i;
//	UINT8 tmp_data;
//
// 
//
//
//	for (i = 0;i < 64;i++)
//	{		
//		//cw_write(i + REG_BATINFO,&cw_bat_config_info[i],1);	 
//	}
//
//
//	for (i = 0;i < 64;i++)
//	{		
//		cw_read(i + REG_BATINFO,&tmp_data,1);
//		Send_Data_To_iPhone(tmp_data);
//	}
// 	 
//}



