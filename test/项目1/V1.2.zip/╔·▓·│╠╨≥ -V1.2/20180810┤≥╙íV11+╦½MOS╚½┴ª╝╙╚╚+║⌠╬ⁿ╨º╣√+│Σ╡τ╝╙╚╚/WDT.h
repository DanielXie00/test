#ifndef _WDT_H_
#define _WDT_H_



#define set_WDTEN \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDTEN = 1;
#define set_WDCLR \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDCLR = 1;
#define set_WDTF  \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDTF = 1;
#define set_WIDPD \
    TA = 0xAA;    \
    TA = 0x55;    \
    WIDPD = 1;
#define set_WDTRF \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDTRF = 1;
#define set_WPS2  \
    TA = 0xAA;    \
    TA = 0x55;    \
    WPS2 = 1;
#define set_WPS1  \
    TA = 0xAA;    \
    TA = 0x55;    \
    WPS1 = 1;
#define set_WPS0  \
    TA = 0xAA;    \
    TA = 0x55;    \
    WPS0 = 1;
#define set_ewrst \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDCON1 |= SET_BIT0;
//==============================
#define clr_WDTEN \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDTEN = 0;
#define clr_WDCLR \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDCLR = 0;
#define clr_WDTF  \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDTF = 0;
#define clr_WIDPD \
    TA = 0xAA;    \
    TA = 0x55;    \
    WIDPD = 0;
#define clr_WDTRF \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDTRF = 0;
#define clr_WPS2  \
    TA = 0xAA;    \
    TA = 0x55;    \
    WPS2 = 0;
#define clr_WPS1  \
    TA = 0xAA;    \
    TA = 0x55;    \
    WPS1 = 0;
#define clr_WPS0  \
    TA = 0xAA;    \
    TA = 0x55;    \
    WPS0 = 0;
#define clr_EWRST \
    TA = 0xAA;    \
    TA = 0x55;    \
    WDCON1 &= CLR_BIT0;
	










#endif