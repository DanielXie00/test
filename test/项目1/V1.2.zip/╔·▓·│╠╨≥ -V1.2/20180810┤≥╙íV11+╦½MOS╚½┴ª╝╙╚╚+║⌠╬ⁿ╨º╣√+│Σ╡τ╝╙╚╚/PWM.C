#include "Typedef.h"
#include "N79E81x.h" 
#include "Scom.h"
#include "main.h"
extern UINT16 TempPwm;

//BYTE OneSecondCnt;
//BYTE WhiteLedControl[4];
void PWM_Init(void)
{
 

	PWM3H = 0;	
	PWM3L = 0;

	PWMPH = 0x03;
	PWMPL = 0xff;
	PWMCON2 = 0x00;		//bit[3:2] Fsys/1
	PWMCON1 |= 0x08;

	//PWMCON0 = 0xC0;//0xCC;		//bit[3:0]=1 PWM ��?3?�����a
	PWMCON0 = 0xC8;//0xCC;//20150703 P CHANNEL
	

	//PWM3
	P0X_OUTPUT(0); 
	P00 = 1;
    
}


void Set_Period_Pwm(U16 pwmval)
{	   

    PWM3H = (pwmval)>>8;
    PWM3L = (pwmval);
	PWMCON0 |= 0x40; 

}


 

 