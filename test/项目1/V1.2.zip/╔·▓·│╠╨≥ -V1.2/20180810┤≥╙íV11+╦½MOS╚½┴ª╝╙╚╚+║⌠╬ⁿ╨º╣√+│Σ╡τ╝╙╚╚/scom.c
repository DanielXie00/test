#include "N79E81x.h"
#include "intrins.h"
#include "Typedef.h"
#include "Scom.h"
#include "main.h"	   

// Use timer1 as baudrate generator
void Init_UART0_Timer1(unsigned int iBaudRate) 
{   
    iBaudRate = iBaudRate;
    CKCON = 0x08; 
	PCON |=  0x00; 
	AUXR1 = 0x00;                                          
    SCON = 0x50;//0x52;
    TMOD = 0x21;
	ES=0;
 	//EnableUartRcv();
    TH1 = 0XFD;
	TL1 = 0XFD;
    TR1 = 1;
}
uint8_t xdata sting_buff[10];

uint8_t number_to_string(uint32_t num,uint8_t *p_char)
{
	uint8_t i = 0;
	uint8_t j;
	uint8_t t;
	
	for (i = 0;i < 10;i++)
	{
		p_char[i] = 0;		
	} 
	i = 0;
	
	while(num != 0)
	{
		p_char[i] = ((uint8_t)(num%10)) + '0';	
			
		num /= 10;
		i++;
	}

	if (i == 0)
	{
		p_char[0] = '0';
		i = 1;
	}

	for(j = 0;j < (i/2);j++)
	{
		t = p_char[j];
		p_char[j] = p_char[i - j - 1];
		p_char[i - j - 1] = t;
	}

	return i;
		
}
 
////-----------------------------------------------------------------------------------------------------------
void Send_Data_To_iPhone (unsigned char cData)  
{
    TI = 0;
    SBUF = cData;
	while (!TI);
    TI = 0;
}

void printf_num(unsigned int cDATA)
{ 
	uint8_t cnt;
	cnt=number_to_string(cDATA,sting_buff);
	my_printf(sting_buff);
	
}

void my_printf (unsigned char *p_char)  
{
    while(*p_char)
	{
		Send_Data_To_iPhone(*p_char);
		p_char++;
	}
}

void my_Sprintf(unsigned char *ch,unsigned int cDATA)
{
    set_WDCLR; //������Ź�
	my_printf (ch);
	my_printf ("-");
	printf_num(cDATA);
	my_printf ("-");	
	my_printf ("\n");//����
}
//-----------------------------------------------------------------------------------------------------------
void UART_ISR(void) interrupt 4 
{
    if (RI == 1) 
    {                       // If reception occur 
        RI = 0;             // Clear reception flag for next reception
 
    }
    else TI = 0;            // If emission occur 
                            // Clear emission flag for next emission     

}
  