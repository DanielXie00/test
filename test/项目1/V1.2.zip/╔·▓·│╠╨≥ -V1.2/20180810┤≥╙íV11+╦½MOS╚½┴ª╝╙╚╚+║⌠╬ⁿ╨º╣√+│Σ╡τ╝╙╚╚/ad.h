
#ifndef __AD_H__
#define __AD_H__






//

//------------------˫¯   ѡ�õĺ궨��-----------------------------//

//#define BAT_AD_GREEN        730
//#define BAT_AD_YELLOW         650
//#define BAT_AD_RED          630
//#define BAT_AD_LOW          550
//#define BAT_AD_VERY_LOW     530
//----------------------------------------------------------------//

////------------------��¯  ѡ�õĺ궨��-----------------------------//

//#define BAT_AD_GREEN        730
//#define BAT_AD_YELLOW         680
//#define BAT_AD_RED          630
//#define BAT_AD_LOW          605
//#define BAT_AD_VERY_LOW     595

//ADֵ	ʹ�ô�����	�ص���	��ѹֵ
//755	0		4.13 
//744	1	744	4.07 
//731	2	736	4.00 
//720	3	720	3.94 
//709	4	715	3.88 
//680	5	702	3.72 
//670	6	696	3.66 
//668	7	675	3.65 
//661	8	668	3.61 
//649	9	662	3.55 
//639	10	645	3.49 
//630			3.45 
//620			3.39 
//610			3.34 
//600			3.28 
//560			3.06 
//

//������
#define BAT_AD_GREEN        710
#define BAT_AD_YELLOW       670
#define BAT_AD_LOW          620 //ֹͣ����
#define BAT_AD_VERY_LOW     545 //500 //���ȼ��
////----------------------------------------------------------------//
//������
#define CHARGE_BAT_AD_GREEN        730
#define CHARGE_BAT_AD_YELLOW       690
#define CHARGE_BAT_AD_LOW          630 //ֹͣ����
#define CHARGE_BAT_AD_VERY_LOW     545 //500 //���ȼ��

#define SUPER_VERY_BAT_LOW 	0
#define VERY_BAT_LOW 	1		   
#define BAT_LOW 		2
#define BAT_YELLOW	    3
#define BAT_GREEN 		4



unsigned int Adc_Sampling(unsigned char ADCChannel);
UINT16 calculateTemp(UINT32 resistance);
void Init_Adc(unsigned char ADCChannel);
void Dis_AdcSampling(void);

UINT8 BAT_volt(void);//
UINT8 BAT_volt_Charge(void);//
//u16 LinearInsert(u16 dat,u16 *tab);
u16 calculateTemp1(u16 advalue); //


void Array_Sort(u16* point, u8 len);
void BAT_CHECK(void);





















#endif