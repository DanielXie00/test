
#ifndef __SYSCONFIG_H__
#define __SYSCONFIG_H__

#include <stdio.h>
#include "intrins.h"
#include "N79E81x.h" 
#include "Typedef.h"
#include "timerx.h"
#include "KeyScanM.h"
#include "Scom.h" 
#include "main.h"
#include "ACC.h"
//#include "Temp.h" 
#include "DATAFLASH.h"
#include "WDT.h"
#include "ad.h"
#include "LEDdriver.h"

//#include "Fuel.h"
#include <cw2015_battery.h>

void CheckSystemIdle(void);
void reset_work_value(void);
void my_reset(void);
void error_led_on_off(void);
void no_cup_led_on_off(void);
void soft_reset(void); //��λ����
void POWER_OFF(void);				
void KBI_init();
void NO_SAVE_POWER_OFF(void);				
void DelayMS(unsigned int ch);
void Halt_OffDevice(void); //�ػ�����

void AutoShutdown(void);





#endif