#ifndef _TIMERX_H_
#define _TIMERX_H_

void Timer0_Init(void);


#endif