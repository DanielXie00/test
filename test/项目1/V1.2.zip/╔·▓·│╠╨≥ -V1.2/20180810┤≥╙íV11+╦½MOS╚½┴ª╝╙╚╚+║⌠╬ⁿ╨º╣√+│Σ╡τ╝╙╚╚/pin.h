#ifndef _PIN_H_
#define _PIN_H_  
 
 

//#define IO_KEY_CHARGE_IN 	P07//???
#define IO_KEY_TEMP_INC 	P02//
#define IO_KEY_TEMP_DEC		P04//
#define IO_KEY_POWER 		P01//
#define IO_KEY_MODE_CHECK	P26
#define IO_KEY_CHARGE_IN  	P07  //���Ѽ��
#define IO_KEY_TEST_MODE 	P30  //����ģʽ����

//#define IO_KEY_CHARGING 	P07 //���IC�ĳ����
#define IO_KEY_CHARGED  	P24//

#define IO_T_Chek	        P03  //�¶Ȳɼ�



#define LED1 				P14//��ɫ
#define LED2 				P13//��ɫ
#define LED3 				P12//��ɫ
#define LED4 				P22//��ɫ
#define LED_RED  			LED1//��ɫ
#define LED_ORANGE 			LED2//��ɫ
#define LED_YELLOW			LED3//��ɫ
#define LED_BLUE 			LED4//��ɫ
//#define LED1 				P22//
//#define LED2 				P12//
//#define LED3 				P13//
//#define LED4 				P14//

//#define MOTOR 				P27//
#define MOTOR 				P27//����


#define LEDG				P21//
#define LEDR				P20//
#define LEDB				P16//
#define P_TEM               P00
#define P_WAX			    P17//
#define VCC1_ON      P23=0
#define VCC1_OFF     P23=1


#define PIN_ON      1
#define PIN_OFF     0



//#define TESEP10  P10

#endif
