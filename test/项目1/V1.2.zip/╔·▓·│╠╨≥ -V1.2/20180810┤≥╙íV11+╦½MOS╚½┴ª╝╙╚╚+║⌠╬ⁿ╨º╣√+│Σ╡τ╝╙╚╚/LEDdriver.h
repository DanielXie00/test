
#ifndef __LEDDRIVER_H__
#define __LEDDRIVER_H__

#include "SysConfig.h"
#define RED_F      1
#define GREEN_F    2
#define BLUE_F     3
#define F_LED_OFF  0
#define motor_on    MOTOR=1
#define motor_off   MOTOR=0


void control_motor(UINT8 times);
void led_light_ctrl(void);
void Motor_program(void);			//2ms


void PWM_RGB(void);
void LED1234(void);//LED����

void RGB_Driver(void);
#endif