#include "N79E81x.h"
#include "Typedef.h"
#include "MAIN.h"

#define FOSC 11059200


#define T200us 0xff00//��ʱֵ 50us

bit f_Time2ms=0;//�������־λ
BYTE Time200usCnt = 0;
u16 pwm_cnt=0;
u16 time_pwm_wax=0;
bit f_hot_mode_ctrl=F_MODE_OFF;
bit f_wax_mode_ctrl=F_MODE_OFF;
extern u8 f_led1_4;//LED��˸��־λ

extern u16 temperature;
//initialize Timer0
void Timer0_Init(void)
{
	CKCON |= 0x08;//T0M=1; //select 1/4 FOSC
	//TMOD=0x10; //16-bit timer 0
	TH0=(unsigned char)(T200us>>8);
	TL0=(unsigned char)T200us;
	TF0=0; //clear flag of overflow
	EA=1;	 //enable all interrupt
	ET0=1; //enable timer 0
	TR0=1;
}

void Timer0_Isr(void) interrupt 1
{
	
	//ET0=0;//�����������ж�
	TF0=0;
 
	TH0=(unsigned char)(T200us>>8);
	TL0=(unsigned char)T200us;
	Time200usCnt++;//50us�ж�һ��
	if(Time200usCnt>=30)//1.5����
	{
		Time200usCnt=0;
		f_Time2ms=1;
	}

	led_light_ctrl();//LED1234���Ƴ���
	RGB_Driver();   //RGB��ɫ�ƿ���
    ET0=1;
}


  
 
 
