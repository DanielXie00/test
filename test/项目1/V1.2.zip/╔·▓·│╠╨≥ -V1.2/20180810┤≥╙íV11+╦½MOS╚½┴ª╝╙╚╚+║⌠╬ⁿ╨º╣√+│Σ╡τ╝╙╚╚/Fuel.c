#include "typedef.h"
#include "ACC.h"
#include "Fuel.h"
#include "Scom.h"


//extern char code cw_bat_config_info[];
extern bit cw_read(unsigned char PointReg,unsigned char *pData,unsigned char Data_Length);
extern bit cw_write(unsigned char PointReg,unsigned char *pData,unsigned char Data_Length);
			
void InitFuel(void)
{
	UINT8 i;
	UINT8 tmp_data;

//	for (i = 0;i < 64;i++)
//	{		
//		Single_WriteI2C(FUEL_ADDR,i + REG_BATINFO,cw_bat_config_info[i]);	 
//	}
//
//
//	for (i = 0;i < 64;i++)
//	{		
//		Send_Data_To_iPhone(Single_ReadI2C(FUEL_ADDR,i + REG_BATINFO));
//	}


	for (i = 0;i < 64;i++)
	{		
		cw_write(i + REG_BATINFO,&cw_bat_config_info[i],1);	 
	}


	for (i = 0;i < 64;i++)
	{		
		cw_read(i + REG_BATINFO,&tmp_data,1);
		Send_Data_To_iPhone(tmp_data);
	}

//	Single_WriteI2C(FUEL_ADDR,FUEL_REG_CONFIG,0x55);	 
//
// 	Send_Data_To_iPhone(0XBB);
//
//	i = Single_ReadI2C(FUEL_ADDR,FUEL_REG_VERSION);	
//	Send_Data_To_iPhone(i);
//
//	i = Single_ReadI2C(FUEL_ADDR,FUEL_REG_VELL_H);	
//	Send_Data_To_iPhone(i);
//
//	i = Single_ReadI2C(FUEL_ADDR,FUEL_REG_VELL_L);	
//	Send_Data_To_iPhone(i);	
//
//	i = Single_ReadI2C(FUEL_ADDR,FUEL_REG_RRT_ALART_H);	
//	Send_Data_To_iPhone(i);
//
//	i = Single_ReadI2C(FUEL_ADDR,FUEL_REG_RRT_ALART_L);	
//	Send_Data_To_iPhone(i);	
//
//
//	i = Single_ReadI2C(FUEL_ADDR,FUEL_REG_CONFIG);	  
//	Send_Data_To_iPhone(i);
		

//	Single_ReadI2C(slave_addr,reg_value);	 
}

//UINT8 ReadFuel(void)
//{
//	UINT8 percent;
//
//	percent = (UINT8)((100 * Single_ReadI2C(FUEL_ADDR,FUEL_REG_VELL_H)) >> 8);	 
//
//	return percent;
//	 
//}
//
//
//void WriteFuel(UINT8 slave_addr,UINT8 reg_value,UINT8 value)
//{
//	Single_WriteI2C(slave_addr,reg_value,value);	 
//}
