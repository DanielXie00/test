#include "N79E81x.h"
#include "TYPEDEF.H"
#include "intrins.h"

#include "DATAFLASH.h"
#include "Scom.h"
#include "main.h"



// BYTE pdata WriteADCCheckParameter[8] = {0xAA,0x02,0x03,0x04,0x05,0x06,0x07,0x88};
// BYTE pdata ReadADCCheckParameter[8] = {0};
//-----------------------------------------------------------------------------------------------------------
//void Clear_BOF(void)
//{
//    TA = 0xAA;
//    TA = 0x55;
//    PMCR &= CLR_BIT3;
//}
//-----------------------------------------------------------------------------------------------------------
void Enable_ISP_Mode(void)
{   
    /* Enable ISP  */ 
    TA = 0xAA;
    TA = 0x55;
    CHPCON |= 0x01;      
}
//-----------------------------------------------------------------------------------------------------------
void Disable_ISP_Mode(void)
{   
    /* Disable ISP */ 
    TA = 0xAA;
    TA = 0x55;
    CHPCON &= 0xFE;      
}
//-----------------------------------------------------------------------------------------------------------
void Trigger_ISP(void)
{       
    TA = 0xAA;
    TA = 0x55;
    ISPTRG |= 0x01;      
}
 
//-----------------------------------------------------------------------------------------------------------
void Erase_DATA(UINT16 Sector)
{ 
	UINT16 u16Count;
	u16Count = Sector;
    set_WDCLR; //������Ź�
    Enable_ISP_Mode();
    ISPCN = ERASE_ALL_DATA;
    
    //for(u16Count=126;u16Count<128;u16Count++)
    {   
        ISPAL = LOBYTE(u16Count*128);               // 96*128=12288=0x3000
        ISPAH = HIBYTE(u16Count*128);               // 96*128=12288=0x3000
        Trigger_ISP();
    } 
    Disable_ISP_Mode();
}
 
BYTE Program_DATA(WORD t_addr,BYTE t_dat)
{     
    set_WDCLR; //������Ź�
    Enable_ISP_Mode();
	ISPAL = t_addr;
    ISPAH = t_addr>>8;
    ISPFD = 0xFF;
    ISPCN = BYTE_PROGRAM_DATA;
    
    ISPFD=t_dat;     
    Trigger_ISP();
        
    Disable_ISP_Mode();

	Enable_ISP_Mode();

	ISPAL = t_addr;
    ISPAH = t_addr>>8;
    ISPCN = FLASH_READ_DATA;
	Trigger_ISP();

	if(ISPFD !=t_dat)
	{
		Disable_ISP_Mode();
		return 0xff;
	}

	Disable_ISP_Mode();
	return 0;
}
//-----------------------------------------------------------------------------------------------------------
BYTE READ_DATA(WORD t_addr)
{
    BYTE temp;
    temp=0;
    EA=0;
	Enable_ISP_Mode();
	ISPAL = t_addr;
	ISPAH = t_addr>>8;
	ISPCN = FLASH_READ_DATA;
	Trigger_ISP();

	temp=ISPFD;
	Disable_ISP_Mode();
    EA=1;
	return temp;
}
    


void Write_Byte_Data_Flash(WORD Addr,BYTE PtrData)
{
    BYTE cout;
	EA = 0;
  	
	Erase_DATA(Addr/128);
	EA = 1;
	for(cout = 0;cout < 10;cout++)
	{	
	   	set_WDCLR; //������Ź�
		//EA = 1;
		EA = 0;
       // DelayMS(40); 
		Program_DATA(Addr,PtrData);	 
      //  DelayMS(40); 
		//EA = 0;
		//DelayMS(4000); 
		if((READ_DATA(Addr) == PtrData))
		{
			EA = 1;
			_nop_();
			_nop_();
			return ;
		}	

	}
	EA = 1;
}   

BYTE Read_Byte_Data_Flash(WORD Addr)
{
 	return READ_DATA(Addr);	 		
}   


      