#ifndef __TYPEDEF_H__
#define __TYPEDEF_H__


typedef bit                   BIT;
typedef unsigned char         UINT8;
typedef unsigned int          UINT16;
typedef unsigned long         UINT32;

typedef char         INT8;
typedef int          INT16;
typedef long         INT32;


typedef unsigned char         U8;
typedef unsigned int          U16;
typedef unsigned long         U32;

typedef unsigned char         uint8;
typedef unsigned int          uint16;
typedef unsigned long         uint32;

typedef unsigned char         uint8_t;
typedef unsigned int          uint16_t;
typedef unsigned long         uint32_t;

typedef unsigned char         uchar;
typedef unsigned int          uint;

//typedef bit                   BIT;
typedef unsigned char         BYTE;
typedef unsigned int          WORD;
//typedef unsigned long         DWORD;
#define   u8   unsigned char
#define   u16  unsigned short 
#define   u32 unsigned int 

//typedef struct
//{
//	BYTE KeyValue;
//	BYTE MusicIndex;
//}MUSIC;

//typedef struct
//{
//	unsigned EnableOnOff :1;
//	unsigned EnablePwm : 1;
//}TEMPLED;





#endif