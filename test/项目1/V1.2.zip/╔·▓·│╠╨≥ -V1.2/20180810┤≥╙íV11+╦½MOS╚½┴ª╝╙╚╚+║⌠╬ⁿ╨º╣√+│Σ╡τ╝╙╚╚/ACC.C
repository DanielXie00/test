#include <intrins.h>
#include "typedef.h"
#include "ACC.h"
#include "MAIN.h"
#include "N79E81x.h"
#include "Scom.h"

static unsigned char xdata dat; 
 
void Delay_xnop(void)
{
 	unsigned char i=5;//32;//64;//128;
 	while(i--);
	//asm("NOP");	asm("NOP");asm("NOP");	asm("NOP");
}
	
void I2C_Start(void)
{
//	P1M1 = 0X10;
//	P1M2 = 0X00;

	I2C_SDA_1;I2C_SCL_1;Delay_xnop();I2C_SDA_0;Delay_xnop();//start
}

void I2C_Stop(void)
{
	I2C_SDA_0;Delay_xnop();I2C_SCL_1;Delay_xnop();I2C_SDA_1;Delay_xnop();//stop
}
/*
BYTE CheckACK(void)
{	
	BYTE temp=0;
	P0M2&=0x40;
	LCD_SCL_1;LCD_SCL_1;LCD_SCL_1;LCD_SCL_1;LCD_SCL_1;
	
	while(LCD_SDA)
	{
		temp++;
		if(temp&0x80)
		{
			LCD_SCL_0;P0M2|=0xc0;
			return 0;
		}
	}
	LCD_SCL_0;P0M2|=0xc0;LCD_SCL_0;//SDA=0;
	return 0xff;
}*/
				  
void I2C_sendbyte(unsigned char dat)
{
  	unsigned char i=0x80;
 
		
	//I2C_SCL_DIR_OUT; 
	//I2C_SDA_DIR_OUT;

	I2C_SCL_0;Delay_xnop();  
  	while(i)
  	{
	    if(dat&i)	I2C_SDA_1; 
	    else			I2C_SDA_0;
		i=i>>1; 
	    I2C_SCL_1;Delay_xnop();              
	    I2C_SCL_0;    
  	}
	//P0M2&=0x40;
	//LCD_SDA_1;Delay_xnop();   
	
	//I2C_SDA_DIR_IN; 
	Delay_xnop();       
    I2C_SCL_1;Delay_xnop();  
   	I2C_SCL_0;Delay_xnop();
}

UINT8 I2C_Rcvbyte(void)
{
	 unsigned char i=0;	
	
	//I2C_SCL_DIR_OUT;
	//I2C_SDA_DIR_IN;
//	P1M1 = 0X18;
//	P1M2 = 0X00;
	I2C_SCL_0;Delay_xnop();
	
	I2CSDA = 1;
	dat = 0;
	while(i<8)
	{
		dat <<=1;
		//Delay_xnop();
		I2C_SCL_1;
		Delay_xnop();
		//I2C_SCL_1;	  		
		
		//if((I2C_SDA_IN & (1<<I2C_SDA_PIN)))
		if(I2CSDA)
		{
			dat |= 0x01;	
		}
		else			
		{
			dat &= ~0x01;
		}		

		I2C_SCL_0;
		Delay_xnop();
				
		i=i+1;			
	}
 
	//Delay_xnop();
	//ACK
 	//I2C_SDA_DIR_OUT;
	Delay_xnop();	
	I2C_SDA_1;Delay_xnop();
	I2C_SCL_1;Delay_xnop();//Delay_xnop();Delay_xnop();Delay_xnop();
	I2C_SCL_0;Delay_xnop();

	return dat;
}


//************************************** 
//��I2C�豸д��һ���ֽ����� 
//************************************** 
void Single_WriteI2C(uchar SlaveAddress,uchar REG_Address,uchar REG_data) 
{ 
    I2C_Start();                  //��ʼ�ź� 
    I2C_sendbyte(SlaveAddress);   //�����豸��ַ+д�ź� 
    I2C_sendbyte(REG_Address);    //�ڲ��Ĵ�����ַ�� 
    I2C_sendbyte(REG_data);       //�ڲ��Ĵ������ݣ� 
    I2C_Stop();                   //����ֹͣ�ź� 
} 
//************************************** 
//��I2C�豸��ȡһ���ֽ����� 
//************************************** 
uchar Single_ReadI2C(uchar SlaveAddress,uchar REG_Address) 
{ 
    uchar Rdata; 
    I2C_Start();                   //��ʼ�ź� 
    I2C_sendbyte(SlaveAddress);    //�����豸��ַ+д�ź� 
    I2C_sendbyte(REG_Address);     //���ʹ洢��Ԫ��ַ����0��ʼ   
    I2C_Start();                   //��ʼ�ź� 
    I2C_sendbyte(SlaveAddress+1);  //�����豸��ַ+���ź� 
    Rdata=I2C_Rcvbyte();       //�����Ĵ������� 
    //I2C_SendACK(1);                //����Ӧ���ź� 
    I2C_Stop();                    //ֹͣ�ź� 
    return Rdata; 
} 

//void ACC_Init(void)
//{
//	UINT8 Temp;
//
//	Single_WriteI2C(SLAVER_ADDR,MODE,0X00);
//	DelayMS(5000); 
//
//	Single_WriteI2C(SLAVER_ADDR,SR,0X00);
//	DelayMS(5000);
//	Single_WriteI2C(SLAVER_ADDR,INTSU,0XF7);
//	DelayMS(5000);
//	Single_WriteI2C(SLAVER_ADDR,MODE,0X01);
//	DelayMS(5000); 
//
//	Single_WriteI2C(SLAVER_ADDR,PDET,0X00);
//	DelayMS(5000); 
//
//	Single_WriteI2C(SLAVER_ADDR,PD,0X00);
//	DelayMS(5000); 		
//
//	Temp = Single_ReadI2C(SLAVER_ADDR,INTSU);  	 
//
//	Temp = Single_ReadI2C(SLAVER_ADDR,MODE);  
//
//	Temp = Single_ReadI2C(SLAVER_ADDR,SR);  
// 	 
//	Temp = Single_ReadI2C(SLAVER_ADDR,PDET);  
//
//	Temp = Single_ReadI2C(SLAVER_ADDR,PD);  
//}
//
//UINT8 GetData(uchar REG_Address)
//{
//	UINT8 H;
//
//	H = Single_ReadI2C(SLAVER_ADDR,REG_Address);
// 
//	return H;
//}
// 
//UINT8 ACC_Get_ACC_value(void)
//{
//	UINT8 TempAccX;
//	UINT8 TempAccY;
//	UINT8 TempAccZ;
//  
//	TempAccX = Single_ReadI2C(SLAVER_ADDR,TILT);    
//	TempAccX = Single_ReadI2C(SLAVER_ADDR,SRST);  
//	TempAccX = GetData(XOUT);
//
//	if (TempAccX > 31)
//	{
//		TempAccX = ((~TempAccX) + 1) & 0X3F;
//	}
//	
//	TempAccY = GetData(YOUT);	
//	
//	if (TempAccY > 31)
//	{
//		TempAccY = ((~TempAccY) + 1) & 0X3F;
//	}
//								  
//	TempAccZ = GetData(ZOUT);	
//	
//	if (TempAccZ > 31)
//	{
//		TempAccZ = ((~TempAccZ) + 1) & 0X3F;
//	}
//
//	//>1.3g
//	if (((TempAccX > 27) && (TempAccX <= 32)) || ((TempAccY > 27) && (TempAccY <= 32)) || ((TempAccZ > 27) && (TempAccZ <= 32)))
//	{
//	 	return SHAKE;
//	}
//	//<0.8g
////	if ((TempAccZ < 17) && (TempAccX > TempAccY) && (TempAccX != 0))
////	{
////	 	return (UP | DOWN);
////	}
////	//<0.8g
////	if ((TempAccZ < 17) && (TempAccY > TempAccX) && (TempAccY != 0))
////	{
////	 	return (RIGHT | LEFT);
////	}
////	//<0.25g		
////	if ((TempAccZ > 6) && (TempAccZ < 18))
////	{
////	 	return (BACK | FRONT);
////	} 
//
//	return 0;  		
//}

 
 					 
	