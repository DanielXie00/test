#ifndef _KEYSCANP_H_
#define _KEYSCANP_H_

//initialize single key
void Init_SingleKeyData(void);

//scan matrix keys to seek whether any key be on or not
unsigned char KeyScan(void);

//convert to special key values
unsigned char ConvertToChar(unsigned char cData,unsigned char cData1);

//seek which matrix key be on
unsigned char GetKeyValue(void);

//scan independant keys
unsigned char SingleKeyScan(void);

//single key event process
//void KeyEvnetDeal(void);

BYTE KeyEvnetDeal(void);


#endif