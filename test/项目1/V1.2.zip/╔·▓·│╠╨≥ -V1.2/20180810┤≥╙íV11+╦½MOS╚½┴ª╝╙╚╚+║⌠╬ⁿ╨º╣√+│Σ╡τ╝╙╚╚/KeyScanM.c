#include "N79E81x.h"
#include "intrins.h"
#include "Typedef.h"
#include "main.h"
#include "Scom.h"
#include "DATAFLASH.h"
#include "WDT.h"
#include "pin.h"

#define MOVE_OPEN_CLOSE_TICK 65000

#define VERSION 12   //�汾��


extern u8 f_led1_4;//LED��˸��־λ
extern bit f_tempctrl;
extern u8 f_motor_on;
extern u8 f_wax_mode;
extern u8 TempLevelNumber;
extern u8 f_mode;//ģʽ�л�
extern u8 f_bat_save;
extern u8 Battery_RGB_Flag;
//extern bit f_hot_mode_ctrl;
//extern bit f_wax_mode_ctrl;
extern u8 f_bat_volt;
//extern u8 f_bat_save;
extern u16 Bat_ad_average;
extern u16 DelayUseCnt;
extern u16 TempPwm;
extern u16 temperature;
extern u16 temperature2;
extern u32 sys_tick;
extern u32 errortick;
extern u32 heat_tick;
extern u32 testcnt;//���ڼ���ϻ�����
extern u16 testcnth,testcntl;
extern u16 Charging_cnt;
bit f_on_off=SHUTDOWN;
bit f_outsid_v=0;
bit f_full_v=1;
bit f_test_mode=0;
u8 f_mode_backup=0;//ģʽ����
u8 f_mode_backup2=0;//ģʽ����
u8 f_wax_backup=0;//ģʽ����
u8 f_wax_backup2=0;//ģʽ����
bit f_outsid_v_backup=0; //�����ר�ý�
u8 f_outsid_v_backup2=0;//�����ר�ý�
u8 f_Battery_check=3;   //��ؼ���־λ
u16 full_v_cnt=0;       //������Ĵ���
extern u16 empty_v_cnt;

u8 Key_Touch =0;
u8 Key_Value =0;
u16 ad_power=0;
u8 code Table[9]={	TEMP_LEVEL_ONE,TEMP_LEVEL_ONE,TEMP_LEVEL_TWO,TEMP_LEVEL_THREE,TEMP_LEVEL_FOUR,\
						TEMP_LEVEL_FIVE,TEMP_LEVEL_SIX,TEMP_LEVEL_SEVEN,TEMP_LEVEL_EIGHT
					};
void key_scannal(void)			//2ms
{	static  u8 Key_Read,Key_State,Key_Long_Delay;//����ȥ��ʱ���ʱ��
	static  u8 Key_Delay=50;
	u8 temp_reg1;
	temp_reg1 =0;
	if(!IO_KEY_POWER)
		temp_reg1 =KEY_ON;   
	if(!IO_KEY_TEMP_INC)
		temp_reg1 =KEY_UP;
	if(!IO_KEY_TEMP_DEC) 
		temp_reg1 =KEY_DOW;
 	if(Key_Read !=temp_reg1)	//������״̬�ٴθı�
	{ 	Key_Read =temp_reg1;	//�����µİ���״̬
		Key_Delay =50;		//����ȥ��ʱ���ʼ��,�м�ֵ�ı�����ó�ֵ
	}
	else if(--Key_Delay ==0)	//����
	{	
        Key_Delay =50; 			//������ʱ50*2ms=100ms
		Key_Touch =Key_Read &(Key_Read ^Key_State);//�ó�������ֵ-��,�ڶ��������Ӧ�ļ�ֵ���̰��жϿ�Key_Touch
		Key_State =Key_Read;	//��ֵ���棬�����жϰ���Key_State
		if(Key_State ==0) //û�а�������
		{	
			Key_Long_Delay =0;		//û�а���ֵ����
			if(!f_on_off && !f_outsid_v)//������ʱ���ػ�,
            {    
                    VCC1_OFF;
                    set_WDCLR; //������Ź�
                    Halt_OffDevice();
                    GPIO_init();  //IO��ʼ��
                    Timer0_Init();
                    Init_UART0_Timer1(9600);  
                    TF0=0;
                    //����ʱ��������ϵͳ����
                //    P_WAX=PIN_OFF;P_TEM=PIN_OFF;
                    TempPwm=0;
                    f_mode=MODE_SHUTDOWN;
                    TR0=1;
                    if(IO_KEY_CHARGE_IN) //������״̬
                    {
                        f_mode=MODE_CHARGING;//������ģʽ
                        f_on_off=OPEN;
                      //  f_full_v = READ_DATA(CHARGE_FULL_FLAG_ADDR);//������
                        GPIO_init();  //IO��ʼ��
                        Timer0_Init();
                        PWM_Init();	
                        TR0=0;                  
                        Init_UART0_Timer1(9600);
                        f_tempctrl=0;
                        temperature=0;
                 //       DelayMS(15000);
//                        ad_power=Adc_Sampling(ADC_BAT_CHANNEL);
                        temperature2=10*Adc_Sampling(ADC_TEMP_CHANNEL1);
                        DelayMS(150);
                        temperature=calculateTemp1(temperature2);  
                        TempLevelNumber=1;
                        //Write_Byte_Data_Flash(BAT_VOL_ADDR,BAT_YELLOW);//�����ص��� ��ַ
                      //  f_bat_volt = READ_DATA(BAT_VOL_ADDR);//������
                      //  if(f_bat_volt>BAT_GREEN) f_bat_volt=BAT_GREEN;
                        f_bat_volt=BAT_volt();
                        if(Battery_RGB_Flag==0) Battery_RGB_Flag=f_bat_volt;
                        if(f_bat_volt>Battery_RGB_Flag) f_bat_volt=Battery_RGB_Flag;//ȡ��Сֵ
                        else if(f_bat_volt<=Battery_RGB_Flag) Battery_RGB_Flag=f_bat_volt;//��ֹ��ѹ������ָʾ�ƴ���
                        if(f_bat_save<=BAT_LOW) f_bat_volt=BAT_LOW;//������ʱ���ﵽ�͵�ˮƽ������ʱ��δ��������������ʾ�Ƶ�
                        switch (f_bat_volt) 
                        {
                           case BAT_GREEN:          {IOCTRL(LEDR,OFF);IOCTRL(LEDB,OFF);  IOCTRL(LEDG,ON);} break;
                           case BAT_YELLOW:           {IOCTRL(LEDR,ON); IOCTRL(LEDB,OFF);  IOCTRL(LEDG,ON);} break;
                           default:                 {IOCTRL(LEDR,ON); IOCTRL(LEDB,OFF);  IOCTRL(LEDG,OFF);} break;
                        }
                        testcnth=READ_DATA(FULL_V_CNTH_ADDR);//������
                        testcntl=READ_DATA(FULL_V_CNTL_ADDR);//������
                        full_v_cnt=testcntl|(testcnth<<8);
                        testcnth=READ_DATA(EMPTY_V_CNTH_ADDR);//������
                        testcntl=READ_DATA(EMPTY_V_CNTL_ADDR);//������
                        empty_v_cnt=testcntl|(testcnth<<8);                          
                        testcnth=READ_DATA(TESTCNTH_ADDR);//������
                        testcntl=READ_DATA(TESTCNTL_ADDR);//������


                        testcnt=testcntl|(testcnth<<8);
                        my_Sprintf("testcnt",testcnt);//��ӡtestcnt 
                        TempLevelNumber=1;
                        TempLevelNumber = READ_DATA(TMEP_ADDR);//������
                        if(TempLevelNumber>=9||TempLevelNumber==0) TempLevelNumber=8; 
                        IOCTRL(MOTOR,MOTOR_ON);	
                        DelayMS(MOVE_OPEN_CLOSE_TICK);
                        IOCTRL(MOTOR,MOTOR_OFF);  
                        TR0=1;
                        IOCTRL(LEDR,OFF); 
                        IOCTRL(LEDB,OFF); 
                        IOCTRL(LEDG,OFF); 
                        IOCTRL(LED1,OFF); 
                        IOCTRL(LED2,OFF); 
                        IOCTRL(LED3,OFF); 
                        IOCTRL(LED4,OFF);  
                        PWM_Init();	
                        
                    }
            }
		}
		else
		{	
			if(++Key_Long_Delay >=30){Key_Long_Delay =30;}
			if(Key_Touch ==KEY_ON) {if(f_on_off||f_outsid_v) Key_Value =VALUE_SET;}//��ֹ����ǰ�е���˸
			if(Key_State ==KEY_ON &&Key_Long_Delay ==18){Key_Value =VALUE_ON;}//200ms*15=3s
            if(f_mode!=MODE_SHUTDOWN) //�ػ�û�а�������
            {
                if(Key_State ==KEY_UP &&Key_Long_Delay ==7) {{Key_Value =VALUE_UP;Key_Long_Delay=0;}}//200ms*15=3s
                if(Key_State ==KEY_DOW &&Key_Long_Delay ==7){{Key_Value =VALUE_DOW;Key_Long_Delay=0;}}//200ms*15=3s
                if(Key_Touch ==KEY_UP)	        {{ Key_Value =VALUE_UP;}}	
                else if(Key_Touch ==KEY_DOW)	{{ Key_Value =VALUE_DOW;}}	
            }
		}
	}
}



void key_process(void)		//1.5ms
{
	if(Key_Value ==0)//����ֵΪ0���Ͳ�ִ������ĳ��򣬼��ٲ���Ҫ���жϣ����Ч��
		return;
    my_Sprintf("Key_Value",Key_Value);//��ӡtestcnt 
    sys_tick=0;
    errortick=0;//���ڴ��������ϼ��
    heat_tick=0;
    DelayUseCnt=0;
    Charging_cnt=0;
	switch(Key_Value)
	{
		case VALUE_ON: 
 			if(f_on_off)  
			{	
                if(f_outsid_v==1)//���ʱ���˳�����ģʽ
                {
                    f_led1_4=0; 
                    f_mode=MODE_CHARGING;//         
                    f_motor_on=2;//����� 
                }
                else  //�ػ�
                {

                    TempPwm=0;

                    f_on_off =SHUTDOWN;//f_outsid_v=0;
                    f_mode=MODE_SHUTDOWN;//�ػ�
                    f_led1_4=0;
                    VCC1_ON;
                    //IOCTRL(LEDR,OFF); 
                    IOCTRL(LEDB,OFF); 
                    IOCTRL(LEDG,OFF); 
                    IOCTRL(MOTOR,MOTOR_ON);
                    IOCTRL(LEDR,ON);
                    DelayMS(MOVE_OPEN_CLOSE_TICK);
                    
                    IOCTRL(MOTOR,MOTOR_OFF);
                    IOCTRL(LEDR,OFF);
                    DelayMS(MOVE_OPEN_CLOSE_TICK);
                    
                    IOCTRL(MOTOR,MOTOR_ON);
                    IOCTRL(LEDR,ON);
                    DelayMS(MOVE_OPEN_CLOSE_TICK);
                    
                    IOCTRL(MOTOR,MOTOR_OFF);
                    IOCTRL(LEDR,OFF); 
                    IOCTRL(LEDB,OFF); 
                    IOCTRL(LEDG,OFF); 
                    IOCTRL(LED1,OFF); 
                    IOCTRL(LED2,OFF); 
                    IOCTRL(LED3,OFF); 
                    IOCTRL(LED4,OFF); 
                   // VCC1_OFF;//���ߣ���ֹ 
                }
			}
			else     //����
			{	
                VCC1_OFF;
                IOCTRL(LEDR,OFF); 
                IOCTRL(LEDB,OFF); 
                IOCTRL(LEDG,OFF); 
                IOCTRL(LED1,OFF); 
                IOCTRL(LED2,OFF); 
                IOCTRL(LED3,OFF); 
                IOCTRL(LED4,OFF);
                f_on_off =OPEN;
                P_WAX=PIN_OFF;
                TempPwm=0;
             
                GPIO_init();  //IO��ʼ��
                Timer0_Init();
                PWM_Init();	
                TR0=0;
                EA=0;
                IOCTRL(MOTOR,MOTOR_ON);	
                DelayMS(MOVE_OPEN_CLOSE_TICK);
                IOCTRL(MOTOR,MOTOR_OFF);
                Init_UART0_Timer1(9600);
                f_tempctrl=0;
                temperature=0;
                DelayMS(15000);

                temperature2=10*Adc_Sampling(ADC_TEMP_CHANNEL1);
                DelayMS(150);
                temperature=calculateTemp1(temperature2);  
                TempLevelNumber=1;f_bat_volt=0;
                TempLevelNumber = READ_DATA(TMEP_ADDR);//������
                if(TempLevelNumber>=9||TempLevelNumber==0) TempLevelNumber=8;   
                f_bat_volt = READ_DATA(BAT_VOL_ADDR);//������

                if(f_bat_volt>BAT_GREEN) f_bat_volt=BAT_GREEN;
                
                testcnth=READ_DATA(FULL_V_CNTH_ADDR);//������
                testcntl=READ_DATA(FULL_V_CNTL_ADDR);//������
                full_v_cnt=testcntl|(testcnth<<8);
                
                testcnth=READ_DATA(EMPTY_V_CNTH_ADDR);//������
                testcntl=READ_DATA(EMPTY_V_CNTL_ADDR);//������
                empty_v_cnt=testcntl|(testcnth<<8);  
                set_WDCLR; //������Ź�
                my_Sprintf("version",VERSION);//��ӡ�汾��
                testcnth=READ_DATA(TESTCNTH_ADDR);//������
                testcntl=READ_DATA(TESTCNTL_ADDR);//������
                set_WDCLR; //������Ź�

//                my_Sprintf("testcnth",testcnth);//��ӡtestcnt 
//                set_WDCLR; //������Ź�
//                my_Sprintf("testcntl",testcntl);//��ӡtestcnt 
                testcnt=testcntl|(testcnth<<8);
                set_WDCLR; //������Ź�

                my_Sprintf("testcnt",testcnt);//��ӡtestcnt 
                f_mode=MODE_Preheating;
                ad_power=Adc_Sampling(ADC_BAT_CHANNEL);
                if((f_bat_volt<=SUPER_VERY_BAT_LOW)&&(ad_power<=BAT_AD_YELLOW)) f_mode=MODE_BAT_LOW;//��ʾ����
                else {f_mode=MODE_POWER;}//��ʾ����
                    EA=1;
                    TR0=1; 
                    IOCTRL(LEDR,OFF); 
                    IOCTRL(LEDB,OFF); 
                    IOCTRL(LEDG,OFF); 
                    IOCTRL(LED1,OFF); 
                    IOCTRL(LED2,OFF); 
                    IOCTRL(LED3,OFF); 
                    IOCTRL(LED4,OFF); 
			}				
			break;
		case VALUE_SET:	    
            switch(f_mode)
            {
                case MODE_SHUTDOWN:break;
                case MODE_PreShutdown:          f_mode=MODE_WAIT;break;
                case MODE_CHARGING://��⣬������û�磬���ܽ��м���
                    f_motor_on=1;
//                    f_bat_volt = READ_DATA(BAT_VOL_ADDR);//������
//                    if(f_bat_volt>=BAT_LOW)
                    {
                        f_mode=MODE_Preheating;f_on_off=OPEN;f_outsid_v=1;//���Ϊ���ģʽ���������ʾ����ģʽ
                    }
//                    else
//                    {
//                        f_mode=MODE_BAT_LOW;f_on_off=OPEN;f_outsid_v=1;//����ʾû����
//                    }
                    break;
                case MODE_Standby:f_mode=MODE_Preheating;break;//���Ϊ����ģʽ���������ʾ����ģʽ
                case MODE_WAIT:f_mode=MODE_Preheating;break;//���Ϊ����ģʽ���������ʾ����ģʽ
                case MODE_WAX:break;
                case MODE_SENSOR1_ERR:f_mode=MODE_Preheating;break;//���Ϊ����ģʽ���������ʾ����ģʽ
                case MODE_WAX_ERR:break;//���Ϊ����ģʽ���������ʾ����ģʽ
                case MODE_Heating://����ڼ���ģʽ�����¶ȵ�����ϣ������BOOSTģʽ
                        if(1==f_tempctrl)
                        {
                            f_mode=MODE_BOOST;//���������ɣ������BOOSTģʽ 
                            f_tempctrl=0;
                            f_motor_on=1;
                        }
                      //  else f_mode=MODE_Preheating;
                        break;                                         
             }
             f_tempctrl=0;
             break;
		case VALUE_UP: if(f_mode==MODE_SHUTDOWN) break;
                    f_tempctrl=0;
                    if(TempLevelNumber<=7) { TempLevelNumber++; Write_Byte_Data_Flash(TMEP_ADDR,TempLevelNumber); }
                    if(TempLevelNumber>8) TempLevelNumber=8;
                    switch(f_mode)
                    { 
                        case MODE_POWER:                f_mode=MODE_Preheating;break;
                        case MODE_POWER_BEFORE_WAX:     f_mode=MODE_Preheating;break;
                        case MODE_Heating:              f_mode=MODE_Preheating;break;
                        case MODE_Standby:              f_mode=MODE_WAIT;break;
                        case MODE_PreShutdown:          f_mode=MODE_WAIT;break;
                        case MODE_BOOST:                f_mode=MODE_Preheating;break;
                        case MODE_WAX:                  break;
                        case MODE_SENSOR1_ERR:          f_mode=MODE_Preheating;break;
                        case MODE_WAX_ERR:              f_mode=MODE_WAX;break;
                        case MODE_CHARGING: f_on_off=OPEN;f_outsid_v=1; f_mode=MODE_WAIT;break;
                        default:break;
                    }
                    break;
		case VALUE_DOW:	
                    if(f_mode==MODE_SHUTDOWN) break;
                    if(TempLevelNumber>=2){f_tempctrl=0;TempLevelNumber--;Write_Byte_Data_Flash(TMEP_ADDR,TempLevelNumber);}
                    switch(f_mode)
                    { 
                        case MODE_POWER:                f_on_off=OPEN;f_outsid_v=1; f_mode=MODE_Preheating;break;
                        case MODE_POWER_BEFORE_WAX:     f_mode=MODE_Preheating;break;
                        case MODE_Heating:              f_mode=MODE_Preheating;break;
                        case MODE_Standby:              f_mode=MODE_WAIT;break;
                        case MODE_PreShutdown:          f_mode=MODE_WAIT;break;
                        case MODE_BOOST:                f_mode=MODE_Preheating;break;
                        case MODE_WAX:                  break;
                        case MODE_SENSOR1_ERR:          f_mode=MODE_Preheating;break;
                        case MODE_WAX_ERR:              f_mode=MODE_WAX;break;
                        case MODE_CHARGING:             f_on_off=OPEN;f_outsid_v=1;  f_mode=MODE_WAIT;break;
                        default :break;
                    }
                    break;
		default :break;
	}
	Key_Value =0;		//�尴��ֵ
       
}



void key_scannal2(void)		//2ms
{	
    static u8 key_delay1,key_delay2,key_delay4;
    if(IO_KEY_CHARGE_IN)			//���õ�Դ���ϼ��,
	{	if(++key_delay1 >=4)//���ʱ���һ�㣬̫����ⲻ��
		{	
            key_delay1 =2;
            f_outsid_v =1;	//�����õ�Դ
            f_outsid_v_backup2=(f_outsid_v^f_outsid_v_backup);  
            if(f_outsid_v_backup2)//����һ������ڣ����ڵ����
            {
                f_motor_on=1;
            }                          
		}
	}
	else if(--key_delay1 <=1)
	{	
        key_delay1 =2;
		f_outsid_v =0;//δ���
	}
    f_outsid_v_backup=f_outsid_v;
	if(!IO_KEY_CHARGED)			//�������ż��
	{	if(++key_delay2 >=20)
		{	
			key_delay2 =10;
			f_full_v =1;
            if(f_Battery_check!=2)
            {
                f_Battery_check=2;//ֻ����һ�θó�������
                full_v_cnt++;//�����������1
                Write_Byte_Data_Flash(FULL_V_CNTH_ADDR,((full_v_cnt>>8)&0x00ff));
                Write_Byte_Data_Flash(FULL_V_CNTL_ADDR,(full_v_cnt&0x00ff));
            }
        }
	}
	else if(--key_delay2 <=2)
	{	
		key_delay2 =10;
        f_full_v =0;
	}
 	if(!IO_KEY_TEST_MODE)			//�������ż��
	{	if(++key_delay4 >=10)
		{	
			key_delay4 =5;
			f_test_mode =1;
        }
	}
	else if(--key_delay4 <=2)
	{	
		key_delay4 =5;
        f_test_mode =0;
	}  
    
//    if(f_on_off||f_outsid_v)//û����֮ǰ������ʾ
//    {
//        if(!IO_KEY_MODE_CHECK)
//        {    if(++key_delay3 >=20)
//            {	
//                key_delay3 =10;
//                if((f_mode!=MODE_WAX_ERR)&&(f_mode!=MODE_SHUTDOWN)&&(f_mode!=MODE_Standby)&&(f_mode!=MODE_PreShutdown)&&(f_mode!=MODE_CHARGING)&&(f_mode!=MODE_BAT_LOW)&&(f_mode!=MODE_WAX))//���������û�й��ϻ���û�йػ�����û���ڹػ�׼���׶�&&(f_mode!=MODE_POWER_BEFORE_WAX)
//                {
//                   f_wax_backup2=MODE_POWER_BEFORE_WAX;
//                   f_wax_backup2=f_wax_backup2^f_wax_backup;
//                   if(f_wax_backup2)  
//                   {
//                       f_mode=MODE_POWER_BEFORE_WAX;
//                       f_motor_on=1;//�����
//                   }
//                    if(f_mode==MODE_POWER_BEFORE_WAX)   
//                    {  
//                        f_mode_backup2=(f_mode^f_mode_backup);  
//                        if(f_mode_backup2)//����һ��wax���,����ȫ�ټ���
//                        {
//                            f_wax_mode=WAX_ALL_SPEED;
//                        }
//                    }                        
//                }
//                 f_wax_backup=f_mode;
//          
//            }    
//        } 
//        else if(--key_delay3 <=2)
//        {	
//            key_delay3 =10;
//            if(f_mode==MODE_WAX)  
//            {
//                f_mode=MODE_Standby;f_wax_mode=WAX_STOP;f_motor_on=1;//�����
//            }
//        }  
//        f_mode_backup =f_mode;   
//    }


}



//-----------------------------------------------------------------------------------------------------------
void KBI_ISR(void) interrupt 7          // Vecotr @  0x3B
{
    
    KBIF = 0x00;                        // Clear KBF flag
    set_WDCLR; //������Ź�
//	KBIE = 0x00;                  // KBI Disable   P01/P07�жϲ�ʹ��                            
//    P_WAX=PIN_OFF;P_TEM=PIN_OFF;
    TempPwm=0;
//    IOCTRL(LEDR,OFF); 
//    IOCTRL(LEDB,OFF); 
//    IOCTRL(LEDG,OFF); 
//    IOCTRL(LED1,OFF); 
//    IOCTRL(LED2,OFF); 
//    IOCTRL(LED3,OFF); 
//    IOCTRL(LED4,OFF); 
}
 
