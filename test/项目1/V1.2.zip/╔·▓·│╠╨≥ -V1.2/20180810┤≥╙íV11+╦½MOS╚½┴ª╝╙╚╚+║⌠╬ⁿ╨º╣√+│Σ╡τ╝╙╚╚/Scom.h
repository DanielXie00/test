#ifndef _SCOM_H_
#define _SCOM_H_
#define FREQ 10





// Use timer1 as baudrate generator
void Init_UART0_Timer1(unsigned int iBaudRate);


void my_printf (unsigned char *p_char); 
void printf_num(unsigned int cDATA);
unsigned char  number_to_string(uint32_t num,uint8_t *p_char);
void my_Sprintf(unsigned char *p_char,unsigned int cDATA);


#endif