#include <stdio.h>
#include "intrins.h"
#include "N79E81x.h" 
#include "Typedef.h"
#include "timerx.h"
#include "KeyScanM.h"
#include "Scom.h" 
#include "main.h"
#include "ACC.h"
#include "Temp.h" 
#include "DATAFLASH.h"
#include "WDT.h"
#include <stdio.h>
#include <string.h>
#include "ad.h"
u16 code NTC_TAB1[]={
10209,
10207,
10205,
10204,
10202,
10200,
10198,
10196,
10194,
10191,
10189,
10186,
10184,
10181,
10178,
10175,
10172,
10169,
10166,
10162,
10159,
10155,
10151,
10147,
10143,
10139,
10134,
10129,
10125,
10120,
10114,
10109,
10103,
10098,
10092,
10085,
10079,
10072,
10065,
10058,
10051,
10043,
10035,
10027,
10019,
10010,
10001,
9992,
9982,
9973,
9962,
9952,
9941,
9930,
9918,
9907,
9894,
9882,
9869,
9856,
9842,
9828,
9813,
9798,
9783,
9767,
9751,
9734,
9717,
9700,
9682,
9663,
9644,
9625,
9605,
9585,
9564,
9542,
9520,
9498,
9475,
9451,
9427,
9403,
9377,
9352,
9325,
9298,
9271,
9243,
9214,
9185,
9155,
9124,
9093,
9062,
9030,
8997,
8963,
8929,
8894,
8859,
8823,
8787,
8749,
8712,
8673,
8634,
8595,
8555,
8514,
8472,
8430,
8388,
8345,
8301,
8257,
8212,
8166,
8120,
8074,
8027,
7979,
7931,
7882,
7833,
7783,
7733,
7683,
7632,
7580,
7528,
7476,
7423,
7370,
7316,
7262,
7208,
7154,
7099,
7043,
6988,
6932,
6876,
6820,
6763,
6706,
6649,
6592,
6535,
6477,
6420,
6362,
6304,
6246,
6188,
6130,
6072,
6014,
5956,
5898,
5839,
5781,
5723,
5666,
5608,
5550,
5492,
5435,
5377,
5320,
5263,
5206,
5150,
5093,
5037,
4981,
4925,
4870,
4815,
4760,
4705,
4651,
4597,
4543,
4490,
4437,
4384,
4332,
4280,
4228,
4177,
4126,
4076,
4026,
3976,
3927,
3878,
3830,
3782,
3734,
3687,
3641,
3595,
3549,
3503,
3458,
3414,
3370,
3326,
3283,
3241,
3198,
3156,
3115,
3074,
3034,
2994,
2954,
2915,
2877,
2839,
2801,
2764,
2727,
2691,
2655,
2619,
2584,
2549,
2516,
2482,
2448,
2415,
2383,
2351,
2319,
2288,
2257,
2227,
2197,
2167,
2138,
2109,
2081,
2053,
2025,
1998,
1971,
1944,
1918,
1892,
1867,
1842,
1817,
1793,
1769,
1745,
1722,
1698,
1676,
1653,
1631,
1610,
1588,
1566,
1546,
1525,
1505,
1485,
1465,
1446,
1427,
1408,
1390,
1371,
1353,
1335,
1318,
1301,
1283,
1267,
1250,
1234,
1218,
1202,
1186,
1171,
1156,
1141,
1126,
1112,
1098,
1083,
1069,
1056,
1043,
1030,
1016,
1003,
991,
978,
966,
954,
942,
930,
918,
907,
896,
885,
874,
863,
852,
842,
832,
821,
811,
801,
792,
782,
773,
763,
754,
745,
737,
728,
719,
710,
702,
693,
685,
677,
669,
661,
654,
646,
638,
631,
624,
617,
610,
602,
595,
589,
582,
575,
569,
562,
556,
549,
544
};


void Init_Adc(unsigned char ADCChannel)
{
	ADCCON0 &= ~0X07;
	ADCCON0 |= (ADCChannel & 0x07); 

	EADC = 0;//disable ADC interrupt
	ADCEX=0;//ADCCON0 &= 0xcf;  //disable converting from P14  
	ADCCON1 |=0x82;   //enable ADC,and sampling frequency is 1/4 Fsys
}
void Dis_AdcSampling(void)
{
	ADCCON1 &= 0x7f;   //disable ADC
}

unsigned int Adc_Sampling(unsigned char ADCChannel)
{
	
	unsigned int iAdcResult=0;
	unsigned int iAdcHiByte=0;
	unsigned int iAdcLowByte=0;
	
	Init_Adc(ADCChannel);     //initialize Adc
	
	ADCI=0;
	ADCS=1;      //start to convert	   	
	
	while(!ADCI)
	;                               //not ends,wait
	iAdcHiByte = ADCH;
	iAdcLowByte = ADCCON0;
	iAdcResult = (iAdcHiByte<<2) + (iAdcLowByte>>6); //get 10-bit adc result 
	return  iAdcResult;
}


u16 calculateTemp1(u16 advalue) //
{
	u16 i; 
	if (advalue >= NTC_TAB1[0]) return 0x3ff;//��·��δ�Ӵ�����
    if(advalue<=NTC_TAB1[350]) return 0x4ff;//��·����������·
	for (i = 0; i< 350;i++)
	{
		if (advalue>NTC_TAB1[i])
		{
		 	return i;
		}	
	}	   
    return 280;	 
} 
//u16 Bat_ad_value=0;
u16 Bat_ad_average=750;
//u8 ad_cnt=0;

UINT8 BAT_volt(void)//
{       
    Bat_ad_average= Adc_Sampling(ADC_BAT_CHANNEL);
    Bat_ad_average= Bat_ad_average + Adc_Sampling(ADC_BAT_CHANNEL);
    Bat_ad_average= Bat_ad_average + Adc_Sampling(ADC_BAT_CHANNEL);
    Bat_ad_average= Bat_ad_average + Adc_Sampling(ADC_BAT_CHANNEL);
    Bat_ad_average =Bat_ad_average>>2;
    if(Bat_ad_average>=0x3ff)                return SUPER_VERY_BAT_LOW; //��ѹ���軵
    else if(Bat_ad_average>=BAT_AD_GREEN)    return BAT_GREEN;//>730��ɫ
    else if(Bat_ad_average>=BAT_AD_YELLOW)   return BAT_YELLOW;//>650��ɫ
    else if(Bat_ad_average>=BAT_AD_LOW)      return BAT_LOW;//>550��ɫ
    else if(Bat_ad_average>=BAT_AD_VERY_LOW) return VERY_BAT_LOW;//530
    else return SUPER_VERY_BAT_LOW;
}
UINT8 BAT_volt_Charge(void)//
{       
    Bat_ad_average= Adc_Sampling(ADC_BAT_CHANNEL);
    Bat_ad_average= Bat_ad_average + Adc_Sampling(ADC_BAT_CHANNEL);
    Bat_ad_average= Bat_ad_average + Adc_Sampling(ADC_BAT_CHANNEL);
    Bat_ad_average= Bat_ad_average + Adc_Sampling(ADC_BAT_CHANNEL);
    Bat_ad_average =Bat_ad_average>>2;
    if(Bat_ad_average>=0x3ff)                return SUPER_VERY_BAT_LOW; //��ѹ���軵
    else if(Bat_ad_average>=CHARGE_BAT_AD_GREEN)    return BAT_GREEN;//>730��ɫ
    else if(Bat_ad_average>=CHARGE_BAT_AD_YELLOW)   return BAT_YELLOW;//>650��ɫ
    else if(Bat_ad_average>=CHARGE_BAT_AD_LOW)      return BAT_LOW;//>550��ɫ
    else if(Bat_ad_average>=CHARGE_BAT_AD_VERY_LOW) return VERY_BAT_LOW;//530
    else return SUPER_VERY_BAT_LOW;
}
//void BAT_CHECK(void)
//{
//    
//      Bat_ad_value += Adc_Sampling(ADC_BAT_CHANNEL);
//      Bat_ad_value += Adc_Sampling(ADC_BAT_CHANNEL);     
//      Bat_ad_value += Adc_Sampling(ADC_BAT_CHANNEL);
//      Bat_ad_value += Adc_Sampling(ADC_BAT_CHANNEL);
//      Bat_ad_average=Bat_ad_value>>2;
//      Bat_ad_value=0;
//}
//void BAT_CHECK(void)
//{
//    ad_cnt++;
//  if(ad_cnt<=8)
//  {   
//      Bat_ad_value += Adc_Sampling(ADC_BAT_CHANNEL);	
//  
//  }
//  else 
//  {
//      ad_cnt=0;
//      Bat_ad_average=Bat_ad_value>>3;
//      Bat_ad_value=0;
//  }
//}

//// ���������㷨 ð���㷨
//void Array_Sort(u16* point, u8 len)
//{
//		u16 temp;
//		u8 i,j;
//		for(i=0;i < len-1;i++)
//		{
//				for(j=0;j <(len-i-1);j++)
//				{
//						if(point[j] > point[j+1])
//						{
//								temp = point[j+1];
//								point[j+1] = point[j];
//								point[j] = temp;
//						}		
//				}
//		}
//}





