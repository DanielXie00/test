#ifndef _KEYSCANM_H_
#define _KEYSCANM_H_



#define KEY_ON  0x12
#define KEY_SET 0x02
#define KEY_UP  0x03
#define KEY_DOW  0x04
#define KEY_MODE  0x22
#define VALUE_ON  0x05
#define VALUE_SET  0x06
#define VALUE_UP  0x07
#define VALUE_DOW  0x08
#define VALUE_SOUND  0x09
#define KEY_C_HCHO_VB  0x10
#define VALUE_MODE     0x25


void key_scannal(void);	//����ɨ��

void key_scannal2(void);	//�ఴ��ɨ��	
void key_process(void);		//2ms

#endif